import { io, Socket } from "socket.io-client";

// Socket client connecting to the current server origin
export const socket: Socket = io(window.location.origin, {
  autoConnect: true,
  reconnection: true,
  reconnectionAttempts: 15,
  reconnectionDelay: 2000,
});
