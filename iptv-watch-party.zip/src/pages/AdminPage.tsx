import React, { useEffect, useState, useRef } from "react";
import { Link } from "react-router-dom";
import { socket } from "../lib/socket";
import { StreamItem } from "../types";
import { 
  KeyRound, Radio, ShieldCheck, Plus, Trash2, Star, 
  Upload, Sparkles, Layers, ListPlus, ChevronLeft, Wifi, Database, Pencil, X
} from "lucide-react";

export default function AdminPage() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [password, setPassword] = useState("");
  const [streams, setStreams] = useState<StreamItem[]>([]);
  const [activeTab, setActiveTab] = useState<"smart" | "direct" | "m3u" | "xtream" | "stalker">("smart");

  // Edit stream state variables
  const [editingStream, setEditingStream] = useState<StreamItem | null>(null);
  const [editName, setEditName] = useState("");
  const [editUrl, setEditUrl] = useState("");
  const [editCategory, setEditCategory] = useState("");
  const [editLogo, setEditLogo] = useState("");

  // Form states
  // Smart Import
  const [smartInput, setSmartInput] = useState("");
  const [smartPortalMac, setSmartPortalMac] = useState("");
  const [smartM3uCategory, setSmartM3uCategory] = useState("Smart Playlist");

  // 1. Direct
  const [directName, setDirectName] = useState("");
  const [directUrl, setDirectUrl] = useState("");
  const [directCategory, setDirectCategory] = useState("");
  const [directLogo, setDirectLogo] = useState("");
  const [directFeatured, setDirectFeatured] = useState(false);

  // 2. M3U Raw content & Remote url
  const [m3uText, setM3uText] = useState("");
  const [m3uUrlInput, setM3uUrlInput] = useState("");
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // 3. Xtream Codes
  const [xtreamUrl, setXtreamUrl] = useState("");
  const [xtreamUser, setXtreamUser] = useState("");
  const [xtreamPass, setXtreamPass] = useState("");

  // 4. Stalker Portal
  const [stalkerUrl, setStalkerUrl] = useState("");
  const [stalkerMac, setStalkerMac] = useState("");

  const [notif, setNotif] = useState<{ text: string; type: "success" | "error" } | null>(null);
  const [loading, setLoading] = useState(false);
  const [editingCategory, setEditingCategory] = useState<string | null>(null);
  const [newCategoryName, setNewCategoryName] = useState("");

  // Bulk actions and Room monitoring states
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [roomsList, setRoomsList] = useState<any[]>([]);

  useEffect(() => {
    // Initial fetch of active streams
    fetch("/api/streams")
      .then(res => res.json())
      .then(data => setStreams(data))
      .catch(() => {});

    // Listen to real-time additions
    const handleStreamsUpdate = (updatedList: StreamItem[]) => {
      setStreams(updatedList);
    };
    socket.on("streams_list", handleStreamsUpdate);

    return () => {
      socket.off("streams_list", handleStreamsUpdate);
    };
  }, []);

  // Sync streams selection state
  useEffect(() => {
    setSelectedIds(prev => prev.filter(id => streams.some(s => s.id === id)));
  }, [streams]);

  const fetchRooms = () => {
    fetch("/api/admin/rooms")
      .then(res => res.json())
      .then(data => setRoomsList(data || []))
      .catch(() => {});
  };

  useEffect(() => {
    if (isAdmin) {
      fetchRooms();
      const interval = setInterval(fetchRooms, 4000);
      return () => clearInterval(interval);
    }
  }, [isAdmin]);

  const handleTerminateRoom = (roomId: string) => {
    if (!confirm("Are you sure you want to terminate this dynamic watch party? Active clients will be disconnected.")) return;
    fetch(`/api/admin/rooms/${roomId}`, { method: "DELETE" })
      .then(res => res.json())
      .then((res: any) => {
        if (res.success) {
          showNotification("Successfully terminated watching room", "success");
          fetchRooms();
        }
      })
      .catch(() => showNotification("Server communication interrupted", "error"));
  };

  const handleBulkDelete = () => {
    if (selectedIds.length === 0) return;

    fetch("/api/admin/streams/delete-multiple", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ids: selectedIds })
    })
      .then(res => res.json())
      .then((res: any) => {
        if (res.success) {
          showNotification(`Bulk deletion complete. Purged ${res.count} channels successfully.`, "success");
          setSelectedIds([]);
        } else {
          showNotification("Failed bulk operations", "error");
        }
      })
      .catch(() => showNotification("Server communication crash", "error"));
  };

  const handleClearCatalog = () => {
    fetch("/api/admin/streams/clear", { method: "POST" })
      .then(res => res.json())
      .then((res: any) => {
        if (res.success) {
          showNotification("Broadcast stream catalog flushed entirely", "success");
          setSelectedIds([]);
        } else {
          showNotification("Failed to flush catalog", "error");
        }
      })
      .catch(() => showNotification("Server communication crash", "error"));
  };

  const handleCleanOffline = () => {
    setLoading(true);
    fetch("/api/admin/streams/clean-offline", { method: "POST" })
      .then(res => res.json())
      .then((res: any) => {
        setLoading(false);
        if (res.success) {
          showNotification(`Auto delete complete. Terminated ${res.count} offline stream channels`, "success");
        }
      })
      .catch(() => {
        setLoading(false);
        showNotification("Server interaction failed", "error");
      });
  };

  const handleAdminVerify = (e: React.FormEvent) => {
    e.preventDefault();
    // Validate with standard local default/common admin pass or server matching
    // Fallback is 'admin' or 'admin123'
    if (password === "admin123" || password === "admin") {
      setIsAdmin(true);
      showNotification("Administrative console unlocked successfully", "success");
    } else {
      alert("Invalid administrative passcode specification");
    }
  };

  const showNotification = (text: string, type: "success" | "error") => {
    setNotif({ text, type });
    setTimeout(() => {
      setNotif(null);
    }, 4000);
  };

  // Add individual stream (Direct Mode)
  const handleAddDirectStream = (e: React.FormEvent) => {
    e.preventDefault();
    if (!directName || !directUrl) return;

    setLoading(true);
    fetch("/api/streams", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: directName.trim(),
        url: directUrl.trim(),
        logo: directLogo.trim(),
        category: directCategory.trim() || "Uncategorized",
        sourceType: "direct",
        featured: directFeatured
      })
    })
      .then(res => res.json())
      .then((res: any) => {
        setLoading(false);
        if (res.success) {
          showNotification(`Direct stream "${directName}" registered successfully`, "success");
          setDirectName("");
          setDirectUrl("");
          setDirectCategory("");
          setDirectLogo("");
          setDirectFeatured(false);
        } else {
          showNotification(res.error || "Failed registration", "error");
        }
      })
      .catch(() => {
        setLoading(false);
        showNotification("Server communication crash", "error");
      });
  };

  // Delete stream
  const handleDeleteStream = (id: string, name: string) => {
    fetch(`/api/streams/${id}`, { method: "DELETE" })
      .then(res => res.json())
      .then((res: any) => {
        if (res.success) {
          showNotification(`Successfully deleted "${name}"`, "success");
        } else {
          showNotification("Failed deletion", "error");
        }
      })
      .catch(() => showNotification("Server communication crash", "error"));
  };

  // Toggle Featured status
  const handleToggleFeatured = (stream: StreamItem) => {
    fetch(`/api/streams/${stream.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ featured: !stream.featured })
    })
      .then(res => res.json())
      .then((res: any) => {
        if (res.success) {
          showNotification(`Featured state updated for ${stream.name}`, "success");
        }
      })
      .catch(() => {});
  };

  const handleUpdateStream = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingStream || !editName || !editUrl) return;

    fetch(`/api/streams/${editingStream.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: editName.trim(),
        url: editUrl.trim(),
        logo: editLogo.trim(),
        category: editCategory.trim() || "Uncategorized"
      })
    })
      .then(res => res.json())
      .then((res: any) => {
        if (res.success) {
          showNotification(`Successfully updated "${editName}"`, "success");
          setEditingStream(null);
          // Locally update streams list
          setStreams(prev => prev.map(s => s.id === editingStream.id ? { ...s, name: editName.trim(), url: editUrl.trim(), logo: editLogo.trim(), category: editCategory.trim() || "Uncategorized" } : s));
        } else {
          showNotification(res.error || "Failed update", "error");
        }
      })
      .catch(() => showNotification("Server communication crash", "error"));
  };

  // Submit Raw M3U bulk content
  const handleImportM3U = (contentStr: string) => {
    if (!contentStr.trim()) return;

    setLoading(true);
    fetch("/api/admin/iptv/m3u", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ m3uContent: contentStr })
    })
      .then(res => res.json())
      .then((res: any) => {
        setLoading(true);
        // Add artificial delay for aesthetic loaders
        setTimeout(() => {
          setLoading(false);
          if (res.success) {
            showNotification(`Parsed and loaded ${res.count} channels successfully from playlist`, "success");
            setM3uText("");
          } else {
            showNotification(res.error || "M3U Import error", "error");
          }
        }, 1200);
      })
      .catch(() => {
        setLoading(false);
        showNotification("Server interaction error", "error");
      });
  };

  // Import Remote M3U via URL
  const handleImportRemoteM3U = (urlStr: string, customCat?: string) => {
    if (!urlStr.trim()) return;
    setLoading(true);
    fetch("/api/admin/iptv/m3u-url", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ playlistUrl: urlStr.trim(), customCategory: customCat })
    })
      .then(res => res.json())
      .then((res: any) => {
        setLoading(false);
        if (res.success) {
          showNotification(`Successfully downloaded and parsed ${res.count} channels from remote link!`, "success");
          setSmartInput("");
          setM3uUrlInput("");
        } else {
          showNotification(res.error || "Failed to download remote M3U playlist.", "error");
        }
      })
      .catch(() => {
        setLoading(false);
        showNotification("Server communication interrupted", "error");
      });
  };

  // Analytics engine for Smart IPTV Import
  const getSmartDetectedType = (input: string) => {
    const trimmed = input.trim();
    if (!trimmed) return null;

    // 1. Raw M3U detection
    if (trimmed.startsWith("#EXTM3U") || trimmed.includes("#EXTINF:")) {
      return {
        type: "m3u_raw",
        title: "Raw M3U Playlist Text",
        badge: "M3U Code Block",
        desc: "Found tag indicators (#EXTM3U). We will extract all custom streams and meta tags from this code."
      };
    }

    // Check if it's a valid URL
    const isUrl = trimmed.match(/^https?:\/\/[^\s/$.?#].[^\s]*$/i);
    if (!isUrl) {
      // Check if it's a MAC Address + URL credentials (Stalker)
      const macMatch = trimmed.match(/([0-9a-f]{2}[:-]){5}([0-9a-f]{2})/i);
      const urlMatch = trimmed.match(/https?:\/\/[^\s/$.?#].[^\s]*/i);
      if (macMatch && urlMatch) {
         return {
           type: "stalker_comb",
           title: "Stalker Portal (MAC Credentials)",
           badge: "Stalker MAC API",
           portalUrl: urlMatch[0],
           macAddress: macMatch[0],
           desc: `Detected MAC Address (${macMatch[0]}) and Portal URL (${urlMatch[0]}).`
         };
      }
      return null;
    }

    const url = trimmed;

    // 2. Xtream Codes detection from URL parameters
    if (url.includes("username=") && url.includes("password=") && (url.includes("player_api.php") || url.includes("get.php"))) {
      try {
        const parsedUrl = new URL(url);
        const serverUrl = `${parsedUrl.protocol}//${parsedUrl.host}`;
        const username = parsedUrl.searchParams.get("username") || parsedUrl.searchParams.get("user") || "";
        const password = parsedUrl.searchParams.get("password") || parsedUrl.searchParams.get("pass") || "";
        return {
          type: "xtream_link",
          title: "Xtream Codes API Server",
          badge: "Xtream Codes API",
          serverUrl,
          username,
          password,
          desc: `Extracted Xtream Server: ${serverUrl}, Username: ${username}`
        };
      } catch {
        // Fallback
      }
    }

    // 3. Stalker Portal URL detection
    if (url.includes("/c/") || url.includes("stalker_portal") || url.includes("portal.php")) {
       return {
         type: "stalker_portal",
         title: "Stalker Portal Link",
         badge: "Stalker Portal",
         portalUrl: url,
         desc: "Stalker portals require both a server link and custom MAC address authorization."
       };
    }

    // 4. Remote M3U Playlist Link
    const isPlaylistExt = url.match(/\.(m3u|txt)(\?|$)/i) || url.includes("get.php?auth=") || url.includes("type=m3u") || url.includes("output=m3u");
    if (isPlaylistExt) {
      return {
        type: "m3u_url",
        title: "Remote M3U Playlist URL",
        badge: "Remote Playlist Link",
        playlistUrl: url,
        desc: "Will fetch full television tables directly from this remote IPTV server link."
      };
    }

    // 5. Single Direct HLS stream URL
    const isSingleStream = url.match(/\.(m3u8|mp4|mkv|mov|avi)(\?|$)/i) || url.includes("output=ts") || url.includes("output=m3u8") || url.includes("/live/");
    if (isSingleStream) {
      // Auto extraction of name
      let autoName = "Automated HLS Stream";
      try {
        const urlObj = new URL(url);
        const pathParts = urlObj.pathname.split("/");
        const lastPart = pathParts[pathParts.length - 1];
        if (lastPart) {
          autoName = decodeURIComponent(lastPart).replace(/\.[^/.]+$/, "").replace(/[_-]/g, " ");
        }
      } catch {
        // Fallback
      }
      return {
        type: "direct_hls",
        title: "Single HLS Broadcast URL",
        badge: "Direct Live Stream",
        url: url,
        name: autoName,
        desc: `Ready to save direct stream as: "${autoName}"`
      };
    }

    // Default to general M3U URL since many m3u URL links are short/masked
    return {
      type: "m3u_url",
      title: "Remote M3U URL / Dynamic Stream",
      badge: "Remote Playlist Link",
      playlistUrl: url,
      desc: "This looks like a playlist link. We can download, parse, and auto-register its contents."
    };
  };

  // Execute Auto Import
  const handleExecuteSmartImport = () => {
    const detected = getSmartDetectedType(smartInput);
    if (!detected) return;

    if (detected.type === "m3u_raw") {
      handleImportM3U(smartInput);
    } else if (detected.type === "m3u_url") {
      handleImportRemoteM3U(detected.playlistUrl, smartM3uCategory);
    } else if (detected.type === "xtream_link") {
      setLoading(true);
      fetch("/api/admin/iptv/xtream", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          serverUrl: detected.serverUrl,
          username: detected.username,
          password: detected.password
        })
      })
        .then(res => res.json())
        .then((res: any) => {
          setLoading(false);
          if (res.success) {
            showNotification(`Synchronized ${res.count} channels from Xtream successfully!`, "success");
            setSmartInput("");
          } else {
            showNotification(res.error || "Xtream fetch failed.", "error");
          }
        })
        .catch(() => {
          setLoading(false);
          showNotification("Xtream Server unreachable", "error");
        });
    } else if (detected.type === "stalker_comb") {
      setLoading(true);
      fetch("/api/admin/iptv/stalker", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          portalUrl: detected.portalUrl,
          macAddress: detected.macAddress
        })
      })
        .then(res => res.json())
        .then((res: any) => {
          setLoading(false);
          if (res.success) {
            showNotification(`Authenticated MAC and synced ${res.count} Stalker channels!`, "success");
            setSmartInput("");
          } else {
            showNotification(res.error || "Stalker handshake failed.", "error");
          }
        })
        .catch(() => {
          setLoading(false);
          showNotification("Stalker Portal unreachable", "error");
        });
    } else if (detected.type === "stalker_portal") {
      if (!smartPortalMac.trim()) {
        alert("Please enter the authorized MAC address for this Stalker portal.");
        return;
      }
      setLoading(true);
      fetch("/api/admin/iptv/stalker", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          portalUrl: detected.portalUrl,
          macAddress: smartPortalMac.trim()
        })
      })
        .then(res => res.json())
        .then((res: any) => {
          setLoading(false);
          if (res.success) {
            showNotification(`Authenticated MAC and synced ${res.count} Stalker channels!`, "success");
            setSmartInput("");
            setSmartPortalMac("");
          } else {
            showNotification(res.error || "Stalker handshake failed.", "error");
          }
        })
        .catch(() => {
          setLoading(false);
          showNotification("Stalker Portal unreachable", "error");
        });
    } else if (detected.type === "direct_hls") {
      setLoading(true);
      fetch("/api/streams", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: detected.name,
          url: detected.url,
          logo: "",
          category: "Smart Streams",
          sourceType: "direct",
          featured: false
        })
      })
        .then(res => res.json())
        .then((res: any) => {
          setLoading(false);
          if (res.success) {
            showNotification(`Direct stream "${detected.name}" imported successfully!`, "success");
            setSmartInput("");
          } else {
            showNotification(res.error || "Failed stream import.", "error");
          }
        })
        .catch(() => {
          setLoading(false);
          showNotification("Server request error", "error");
        });
    }
  };

  // Drag & Drop M3U File Parser selectors
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) {
      readAndProcessM3UFile(file);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      readAndProcessM3UFile(file);
    }
  };

  const readAndProcessM3UFile = (file: File) => {
    if (!file.name.endsWith(".m3u") && !file.name.endsWith(".txt") && !file.name.endsWith(".m3u8")) {
      alert("Please upload a raw plain text or M3U formatted file list.");
      return;
    }
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (text) {
        handleImportM3U(text);
      }
    };
    reader.readAsText(file);
  };

  // Xtream Codes automated crawling API
  const handleImportXtream = (e: React.FormEvent) => {
    e.preventDefault();
    if (!xtreamUrl || !xtreamUser || !xtreamPass) return;

    setLoading(true);
    fetch("/api/admin/iptv/xtream", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        serverUrl: xtreamUrl.trim(),
        username: xtreamUser.trim(),
        password: xtreamPass.trim()
      })
    })
      .then(res => res.json())
      .then((res: any) => {
        setLoading(false);
        if (res.success) {
          showNotification(`Harvested and saved ${res.count} automated channels from Xtream Server`, "success");
          setXtreamUrl("");
          setXtreamUser("");
          setXtreamPass("");
        } else {
          showNotification(res.error || "Xtream Codes API fetch failed.", "error");
        }
      })
      .catch(() => {
        setLoading(false);
        showNotification("Server connection refused", "error");
      });
  };

  // Stalker Portal Mac Handshake API
  const handleImportStalker = (e: React.FormEvent) => {
    e.preventDefault();
    if (!stalkerUrl || !stalkerMac) return;

    setLoading(true);
    fetch("/api/admin/iptv/stalker", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        portalUrl: stalkerUrl.trim(),
        macAddress: stalkerMac.trim()
      })
    })
      .then(res => res.json())
      .then((res: any) => {
        setLoading(false);
        if (res.success) {
          showNotification(`Authorized MAC and synced ${res.count} Stalker channels successfully`, "success");
          setStalkerUrl("");
          setStalkerMac("");
        } else {
          showNotification(res.error || "Stalker Portal API handshake failed.", "error");
        }
      })
      .catch(() => {
        setLoading(false);
        showNotification("Server interaction error", "error");
      });
  };

  // Onboarding security screen
  if (!isAdmin) {
    return (
      <div id="iptv_admin_verify" className="min-h-screen bg-neutral-950 flex flex-col items-center justify-center p-6 text-neutral-100 font-sans selection:bg-orange-500">
        <div className="w-full max-w-md bg-neutral-900 border border-white/5 rounded-3xl p-6 md:p-8 shadow-2xl flex flex-col gap-6">
          <div className="flex flex-col items-center gap-2">
            <div className="p-3 bg-red-500/10 text-red-500 border border-red-500/20 rounded-2xl">
              <KeyRound className="w-8 h-8" />
            </div>
            <h3 className="font-extrabold text-white text-xl tracking-tight mt-1">Superuser Admin Terminal</h3>
            <p className="text-xs text-neutral-500 text-center leading-relaxed">
              Input the default system passcode to gain access to stream deletion and bulk automated parsing nodes.
            </p>
          </div>
          <form onSubmit={handleAdminVerify} className="space-y-4">
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="E.g., admin123"
              className="w-full bg-neutral-950 border border-white/10 rounded-xl px-4 py-3.5 text-center text-sm text-white font-mono focus:outline-none focus:border-red-500/50 transition"
            />
            <button
              type="submit"
              className="w-full py-3.5 bg-gradient-to-r from-orange-500 to-red-600 text-white font-extrabold rounded-xl transition shadow-lg text-xs uppercase tracking-widest cursor-pointer hover:brightness-110"
            >
              Verify Passcode
            </button>
            <Link to="/streams" className="block text-center text-xs text-neutral-500 hover:text-white transition">
              Cancel and Return
            </Link>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans selection:bg-orange-500 pb-16">
      
      {/* Toast Notification */}
      {notif && (
        <div className={`fixed bottom-6 right-6 z-50 px-5 py-3.5 rounded-xl border shadow-2xl animate-fade-in flex items-center gap-2.5 text-xs font-bold ${
          notif.type === "success" 
            ? "bg-emerald-950 border-emerald-500/30 text-emerald-400" 
            : "bg-red-950 border-red-500/30 text-red-400"
        }`}>
          <ShieldCheck className="w-4 h-4 shrink-0" />
          <span>{notif.text}</span>
        </div>
      )}

      {/* Header */}
      <nav className="px-6 py-4 bg-black/40 backdrop-blur-md border-b border-white/10 sticky top-0 z-50 flex items-center justify-between">
        <Link 
          to="/streams" 
          className="flex items-center gap-2 text-sm text-neutral-400 hover:text-white transition"
        >
          <ChevronLeft className="w-4 h-4" />
          Streams Gallery
        </Link>
        <span className="text-xs text-neutral-500 font-mono">Administrative Platform Workspace</span>
      </nav>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto w-full px-6 mt-10 grid grid-cols-1 lg:grid-cols-5 gap-8">
        
        {/* Left Column: Forms */}
        <div className="lg:col-span-2 flex flex-col gap-6">
          <div className="bg-neutral-900 border border-white/5 rounded-3xl p-6 shadow-xl overflow-hidden relative">
            <div className="flex items-center gap-2 mb-5">
              <Plus className="w-5 h-5 text-orange-500" />
              <h3 className="text-base font-black text-white">Import IPTV Source</h3>
            </div>

            {/* TAB SELECTORS */}
            <div className="grid grid-cols-5 gap-0.5 bg-neutral-950 p-1 rounded-xl border border-white/5 text-[9px] uppercase font-bold text-center tracking-wide mb-5">
              {(["smart", "direct", "m3u", "xtream", "stalker"] as const).map(tab => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`py-2 rounded-lg transition cursor-pointer ${activeTab === tab ? "bg-neutral-800 text-white" : "text-neutral-500 hover:text-neutral-300"}`}
                >
                  {tab}
                </button>
              ))}
            </div>

            {/* TAB PANES */}
            {activeTab === "smart" && (
              <div className="space-y-4 animate-fade-in">
                <div className="text-xs text-neutral-400 leading-relaxed">
                  <span className="font-bold text-orange-500">Auto-Detect Stream or Playlist:</span> Paste any direct HLS stream link, M3U raw code, remote playlist link (.m3u), Xtream credential URL, or Stalker portal details. Our system will analyze it instantly.
                </div>

                <div className="flex flex-col gap-1.5 font-sans">
                  <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider">Paste raw data or link address</span>
                  <textarea
                    rows={4}
                    value={smartInput}
                    onChange={(e) => setSmartInput(e.target.value)}
                    placeholder="E.g., http://iptv-server.xyz/get.php?username=xxx&password=yyy&#10;Or paste raw M3U playlist code..."
                    className="w-full bg-neutral-950 border border-white/10 rounded-xl px-3 py-2.5 text-xs font-mono text-neutral-200 placeholder-neutral-700 focus:outline-none focus:border-orange-500/50"
                  ></textarea>
                </div>

                {smartInput.trim() && (() => {
                  const detected = getSmartDetectedType(smartInput);
                  if (!detected) {
                    return (
                      <div className="p-3.5 bg-neutral-950 border border-white/5 rounded-xl text-center">
                        <span className="text-xs text-neutral-600">Awaiting recognized format parameters...</span>
                      </div>
                    );
                  }

                  return (
                    <div className="p-4 bg-orange-500/5 border border-orange-500/15 rounded-2xl flex flex-col gap-3 animate-fade-in">
                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        <span className="text-xs font-black text-white">{detected.title}</span>
                        <span className="text-[9px] font-bold px-2 py-0.5 bg-orange-500 text-neutral-950 rounded-full uppercase tracking-wider">
                          {detected.badge}
                        </span>
                      </div>

                      <p className="text-[11px] text-neutral-400 leading-normal">{detected.desc}</p>

                      {detected.type === "m3u_url" && (
                        <div className="flex flex-col gap-1 mt-1 font-sans">
                          <label className="text-[9px] font-bold text-neutral-500 uppercase">Save Group / Category as Name</label>
                          <input
                            type="text"
                            value={smartM3uCategory}
                            onChange={(e) => setSmartM3uCategory(e.target.value)}
                            placeholder="E.g., Sky News, Live TV"
                            className="bg-neutral-950 border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-orange-500/30"
                          />
                        </div>
                      )}

                      {detected.type === "stalker_portal" && (
                        <div className="flex flex-col gap-1 mt-1 font-sans">
                          <label className="text-[9px] font-bold text-neutral-500 uppercase">MAC Address Specification *</label>
                          <input
                            type="text"
                            value={smartPortalMac}
                            onChange={(e) => setSmartPortalMac(e.target.value)}
                            placeholder="E.g., 00:1A:79:XX:XX:XX"
                            className="bg-neutral-950 border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white uppercase font-mono focus:outline-none focus:border-orange-500/30"
                          />
                        </div>
                      )}

                      <button
                        onClick={handleExecuteSmartImport}
                        disabled={loading || (detected.type === "stalker_portal" && !smartPortalMac.trim())}
                        className="w-full py-2.5 bg-gradient-to-r from-orange-500 to-red-600 text-white font-extrabold rounded-xl text-xs transition uppercase tracking-wider hover:brightness-110 disabled:opacity-40 cursor-pointer flex items-center justify-center gap-1.5 shadow-md"
                      >
                        {loading ? "Registering Streams..." : "Execute Smart Import"}
                      </button>
                    </div>
                  );
                })()}
              </div>
            )}

            {activeTab === "direct" && (
              <form onSubmit={handleAddDirectStream} className="space-y-4">
                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-neutral-500 uppercase">Stream Name *</label>
                  <input
                    type="text" required value={directName} onChange={(e) => setDirectName(e.target.value)}
                    placeholder="E.g., Sky News HD"
                    className="bg-neutral-950 border border-white/10 rounded-lg px-3.5 py-2.5 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-orange-500/50"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-neutral-500 uppercase">Playback URL (.m3u8 HLS / .mp4) *</label>
                  <input
                    type="text" required value={directUrl} onChange={(e) => setDirectUrl(e.target.value)}
                    placeholder="https://.../stream.m3u8"
                    className="bg-neutral-950 border border-white/10 rounded-lg px-3.5 py-2.5 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-orange-500/50 font-mono"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-neutral-500 uppercase">Category</label>
                    <input
                      type="text" value={directCategory} onChange={(e) => setDirectCategory(e.target.value)}
                      placeholder="E.g., News, Tech"
                      className="bg-neutral-950 border border-white/10 rounded-lg px-3 gap-2.5 py-2.5 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-orange-500/50"
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-neutral-500 uppercase">Logo Link URL</label>
                    <input
                      type="text" value={directLogo} onChange={(e) => setDirectLogo(e.target.value)}
                      placeholder="https://.../thumb.png"
                      className="bg-neutral-950 border border-white/10 rounded-lg px-3.5 py-2.5 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-orange-500/50"
                    />
                  </div>
                </div>
                <label className="flex items-center gap-2 pt-1 select-none text-xs text-neutral-400 cursor-pointer">
                  <input
                    type="checkbox" checked={directFeatured} onChange={(e) => setDirectFeatured(e.target.checked)}
                    className="w-4 h-4 accent-orange-500 rounded"
                  />
                  Mark as Promoted / Featured Stream
                </label>
                <button
                  type="submit" disabled={loading}
                  className="w-full py-3 bg-gradient-to-r from-orange-500 to-red-650 text-white font-extrabold rounded-lg text-xs transition uppercase tracking-wide disabled:opacity-50 cursor-pointer hover:brightness-110 shadow-lg"
                >
                  {loading ? "Recording Stream..." : "Register Stream"}
                </button>
              </form>
            )}

            {activeTab === "m3u" && (
              <div className="space-y-4">
                <div className="text-xs text-neutral-400 leading-relaxed mb-1">
                  Presents multiple loading schemes: Upload file tables, fetch playlist link directly or paste code.
                </div>

                {/* Usability Pattern matching: Drag & Drop File Upload */}
                <div
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer flex flex-col items-center justify-center gap-2.5 transition ${
                    isDragging 
                      ? "bg-orange-500/15 border-orange-500 text-orange-400 shadow-inner" 
                      : "bg-neutral-950 hover:bg-neutral-900 border-white/5 text-neutral-400 hover:text-neutral-350"
                  }`}
                >
                  <Upload className="w-8 h-8 text-neutral-500 animate-pulse" />
                  <div className="text-xs">
                    <span className="font-bold text-orange-500">Drag and drop .m3u</span> or click to upload
                  </div>
                  <span className="text-[10px] text-neutral-600">Standard M3U/TXT files supported</span>
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileSelect}
                    accept=".m3u,.m3u8,.txt"
                    className="hidden"
                  />
                </div>

                <div className="flex flex-col gap-1.5 font-sans">
                  <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider">Or Download Remote M3U URL Link</span>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={m3uUrlInput}
                      onChange={(e) => setM3uUrlInput(e.target.value)}
                      placeholder="https://.../playlist.m3u"
                      className="flex-1 bg-neutral-950 border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-orange-500/50 font-mono"
                    />
                    <button
                      onClick={() => handleImportRemoteM3U(m3uUrlInput, "M3U Link Download")}
                      disabled={loading || !m3uUrlInput.trim()}
                      className="px-4 py-2 bg-gradient-to-r from-orange-500 to-red-650 hover:brightness-110 text-white font-extrabold text-xs rounded-lg transition disabled:opacity-40 cursor-pointer"
                    >
                      Fetch
                    </button>
                  </div>
                </div>

                <div className="flex flex-col gap-1.5 font-sans">
                  <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider font-sans">Or Paste Raw Playlist Code</span>
                  <textarea
                    rows={4}
                    value={m3uText}
                    onChange={(e) => setM3uText(e.target.value)}
                    placeholder="#EXTM3U&#10;#EXTINF:-1 tvg-logo='http://icon' group-title='Movies',Teaser Channel&#10;http://sample.com/playlist.m3u8"
                    className="w-full bg-neutral-950 border border-white/10 rounded-lg px-3 py-2 text-[10px] font-mono text-neutral-300 focus:outline-none focus:border-orange-500/50"
                  ></textarea>
                </div>

                <button
                  onClick={() => handleImportM3U(m3uText)}
                  disabled={loading || !m3uText.trim()}
                  className="w-full py-3 bg-gradient-to-r from-orange-500 to-red-650 text-white font-extrabold rounded-lg text-xs transition uppercase tracking-wide disabled:opacity-50 cursor-pointer hover:brightness-110 shadow-lg font-sans"
                >
                  {loading ? "Processing Playlist..." : "Bulk Load Paste Content"}
                </button>
              </div>
            )}

            {activeTab === "xtream" && (
              <form onSubmit={handleImportXtream} className="space-y-4">
                <div className="text-xs text-neutral-400 mb-1 leading-relaxed">
                  Automated channel crawl. Fetches channel tables via standard <span className="font-semibold text-neutral-200">player_api.php</span> parameters.
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-neutral-500 uppercase">Server Address base URL *</label>
                  <input
                    type="text" required value={xtreamUrl} onChange={(e) => setXtreamUrl(e.target.value)}
                    placeholder="http://iptvserver.xyz:8080"
                    className="bg-neutral-950 border border-white/10 rounded-lg px-3.5 py-2.5 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-orange-500/50"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-neutral-500 uppercase">Username *</label>
                    <input
                      type="text" required value={xtreamUser} onChange={(e) => setXtreamUser(e.target.value)}
                      placeholder="User details"
                      className="bg-neutral-950 border border-white/10 rounded-lg px-3 py-2.5 text-xs text-white focus:outline-none focus:border-orange-500/50"
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-neutral-500 uppercase">Password *</label>
                    <input
                      type="password" required value={xtreamPass} onChange={(e) => setXtreamPass(e.target.value)}
                      placeholder="Secret"
                      className="bg-neutral-950 border border-white/10 rounded-lg px-3 py-2.5 text-xs text-white focus:outline-none focus:border-orange-500/50"
                    />
                  </div>
                </div>
                <button
                  type="submit" disabled={loading}
                  className="w-full py-3 bg-gradient-to-r from-orange-500 to-red-650 text-white font-extrabold rounded-lg text-xs transition uppercase tracking-wide disabled:opacity-50 cursor-pointer hover:brightness-110 shadow-lg"
                >
                  {loading ? "Crawling Channel tables..." : "Synchronize Xtream Codes"}
                </button>
              </form>
            )}

            {activeTab === "stalker" && (
              <form onSubmit={handleImportStalker} className="space-y-4">
                <div className="text-xs text-neutral-400 mb-1 leading-relaxed">
                  Crawls channel maps from stalker portal after generating MAC authorized cookies.
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-neutral-500 uppercase">Portal URL *</label>
                  <input
                    type="text" required value={stalkerUrl} onChange={(e) => setStalkerUrl(e.target.value)}
                    placeholder="http://stalkerportal.io/c"
                    className="bg-neutral-950 border border-white/10 rounded-lg px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-orange-500/50"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-neutral-500 uppercase">MAC Address *</label>
                  <input
                    type="text" required value={stalkerMac} onChange={(e) => setStalkerMac(e.target.value)}
                    placeholder="00:1A:79:XX:XX:XX"
                    className="bg-neutral-950 border border-white/10 rounded-lg px-3.5 py-2.5 text-xs text-white focus:outline-none font-mono focus:border-orange-500/50"
                  />
                </div>
                <button
                  type="submit" disabled={loading}
                  className="w-full py-3 bg-gradient-to-r from-orange-500 to-red-650 text-white font-extrabold rounded-lg text-xs transition uppercase tracking-wide disabled:opacity-50 cursor-pointer hover:brightness-110 shadow-lg"
                >
                  {loading ? "Issuing MAC Handshake..." : "Import Stalker Portal"}
                </button>
              </form>
            )}

          </div>
        </div>

        {/* Right Column: Collection Catalog List & Active Rooms */}
        <div className="lg:col-span-3 flex flex-col gap-6">
          
          {/* Stream Database Catalog card */}
          <div className="bg-neutral-900 border border-white/5 rounded-3xl p-6 shadow-xl flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
                <div>
                  <h3 className="font-extrabold text-white text-base tracking-tight">Interactive Stream Catalog</h3>
                  <p className="text-xs text-neutral-500">IPTV channels currently stored in-memory</p>
                </div>
                <span className="text-[10px] bg-neutral-950 px-2.5 py-1 rounded-full border border-white/5 font-mono text-neutral-400">
                  Total Channels: {streams.length}
                </span>
              </div>

              {/* Advanced Admin Actions Row */}
              {streams.length > 0 && (
                <div className="bg-neutral-950 p-3 rounded-2xl border border-white/5 mb-4 flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-3">
                    <label className="flex items-center gap-1.5 cursor-pointer text-neutral-300 font-bold">
                      <input
                        type="checkbox"
                        checked={selectedIds.length === streams.length && streams.length > 0}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedIds(streams.map(s => s.id));
                          } else {
                            setSelectedIds([]);
                          }
                        }}
                        className="rounded border-white/10 bg-neutral-900 text-orange-550 focus:ring-0 cursor-pointer"
                      />
                      <span>Select All ({selectedIds.length})</span>
                    </label>
                  </div>

                  <div className="flex items-center gap-2 flex-wrap">
                    <button
                      onClick={handleBulkDelete}
                      disabled={selectedIds.length === 0}
                      className="px-3 py-1.5 bg-red-600 hover:bg-red-500 disabled:opacity-40 text-white font-extrabold text-[11px] rounded-xl transition cursor-pointer"
                    >
                      Delete Selected
                    </button>
                    <button
                      onClick={handleCleanOffline}
                      disabled={loading}
                      className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-750 text-neutral-200 font-bold text-[11px] rounded-xl transition cursor-pointer"
                    >
                      Clean Offline
                    </button>
                    <button
                      onClick={handleClearCatalog}
                      className="px-3 py-1.5 bg-red-950/40 hover:bg-red-900 text-red-450 font-bold text-[11px] rounded-xl transition cursor-pointer"
                    >
                      Clear List
                    </button>
                  </div>
                </div>
              )}

              {/* Streams table/list list */}
              <div id="admin_registered_table" className="space-y-2 max-h-[360px] overflow-y-auto pr-1">
                {streams.length === 0 ? (
                  <div className="py-20 text-center text-xs text-neutral-600 flex flex-col items-center justify-center gap-2">
                    <Radio className="w-8 h-8 animate-spin text-neutral-700" />
                    <span>No stream channels registered. Import a list using the options on the left.</span>
                  </div>
                ) : (
                  streams.map((item) => {
                    const isChecked = selectedIds.includes(item.id);
                    const isOffline = item.status === "offline";
                    return (
                      <div 
                        key={item.id}
                        className={`p-3 rounded-xl border flex items-center justify-between gap-4 transition ${
                          isChecked 
                            ? "bg-orange-500/5 border-orange-500/20" 
                            : isOffline 
                              ? "bg-neutral-950/40 border-red-900/10 opacity-70"
                              : "bg-neutral-950 border-white/5 hover:border-white/10"
                        }`}
                      >
                        <div className="flex items-center gap-3 overflow-hidden">
                          {/* Selection Checkbox */}
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => {
                              setSelectedIds(prev =>
                                prev.includes(item.id)
                                  ? prev.filter(id => id !== item.id)
                                  : [...prev, item.id]
                              );
                            }}
                            className="rounded border-white/10 bg-neutral-900 text-orange-550 focus:ring-0 cursor-pointer shrink-0"
                          />

                          {/* Stream image */}
                          <div className="w-9 h-9 rounded bg-neutral-900 border border-white/5 overflow-hidden shrink-0">
                            <img 
                              src={item.logo || "https://images.unsplash.com/photo-1542204172-e7052809a936?w=80&fit=crop&q=80"} 
                              alt={item.name}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover"
                            />
                          </div>
                          
                          <div className="truncate">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="text-xs font-bold text-neutral-100">{item.name}</span>
                              <span className="text-[9px] bg-neutral-800 text-neutral-400 px-1.5 py-0.2 rounded uppercase font-semibold">
                                {item.sourceType}
                              </span>
                              {isOffline && (
                                <span className="text-[8px] bg-red-600 text-white font-black px-1 rounded uppercase tracking-wider">
                                  Offline
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] text-neutral-500 truncate block mt-0.5 font-mono">{item.url}</span>
                          </div>
                        </div>

                        {/* Controls */}
                        <div className="flex items-center gap-2 shrink-0">
                          {/* Star/Featured */}
                          <button
                            onClick={() => handleToggleFeatured(item)}
                            className={`p-1.5 rounded transition cursor-pointer ${item.featured ? "text-yellow-500 bg-yellow-500/10" : "text-neutral-500 hover:text-white"}`}
                            title="Featured Stream"
                          >
                            <Star className="w-4 h-4 fill-current" />
                          </button>

                          {/* Edit info */}
                          <button
                            onClick={() => {
                              setEditingStream(item);
                              setEditName(item.name);
                              setEditUrl(item.url);
                              setEditCategory(item.category || "");
                              setEditLogo(item.logo || "");
                            }}
                            className="p-1.5 bg-neutral-850 hover:bg-neutral-700 text-neutral-300 hover:text-white rounded transition cursor-pointer"
                            title="Edit Stream Info"
                          >
                            <Pencil className="w-4 h-4" />
                          </button>
                          
                          {/* Deletion */}
                          <button
                            onClick={() => handleDeleteStream(item.id, item.name)}
                            className="p-1.5 bg-red-950/20 hover:bg-red-650 hover:text-white text-red-500 rounded transition cursor-pointer"
                            title="Delete Stream Entry"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            <div className="mt-4 flex items-center justify-between border-t border-white/5 pt-4 text-[10px] text-neutral-550 font-medium">
              <span className="flex items-center gap-1">
                <Wifi className="w-3.5 h-3.5 text-orange-500 animate-pulse" />
                Continuous background stream validation maintains live directories
              </span>
            </div>
          </div>

          {/* ACTIVE WATCH PARTY ROOMS MANAGER SECTION */}
          <div className="bg-neutral-900 border border-white/5 rounded-3xl p-6 shadow-xl space-y-4">
            <div>
              <h3 className="font-extrabold text-white text-base tracking-tight">Active Watching Rooms Database</h3>
              <p className="text-xs text-neutral-550">Overview of all user-generated watch party rooms in progress</p>
            </div>

            <div className="space-y-2 max-h-[300px] overflow-y-auto">
              {roomsList.length === 0 ? (
                <p className="text-xs text-neutral-600 italic text-center py-8">No watch rooms are currently active on the network.</p>
              ) : (
                roomsList.map((roomItem) => (
                  <div 
                    key={roomItem.id}
                    className="p-3.5 bg-neutral-950 rounded-2xl border border-white/5 flex items-center justify-between gap-4 text-xs"
                  >
                    <div className="truncate flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-extrabold text-white text-xs">{roomItem.name}</span>
                        <span className="font-mono text-[9px] bg-neutral-900 border border-white/5 text-orange-400 px-1.5 py-0.5 rounded-md font-bold uppercase tracking-wider">
                          Code: {roomItem.id}
                        </span>
                        {roomItem.password && (
                          <span className="text-[9px] bg-yellow-500/10 text-yellow-500 px-1.5 py-0.5 rounded-md font-bold">
                            Password Protected
                          </span>
                        )}
                      </div>
                      <div className="mt-1 text-neutral-500 truncate space-y-0.5 text-[10px]">
                        <span className="block truncate">Broadcast URL: <span className="font-mono text-neutral-400">{roomItem.mediaUrl}</span></span>
                        <span className="block truncate">Viewing Channel Name: <span className="text-neutral-300 font-semibold">{roomItem.mediaName || "Not named"}</span></span>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <span className="text-[10px] bg-neutral-900 px-2 py-1 rounded-lg border border-white/5 text-neutral-300 font-mono">
                        Viewers: <span className="font-bold text-orange-400">{roomItem.users?.length || 0}</span>
                      </span>
                      <button
                        onClick={() => handleTerminateRoom(roomItem.id)}
                        className="p-2 bg-red-500/10 hover:bg-red-600 hover:text-white text-red-500 rounded-xl transition cursor-pointer"
                        title="Force Terminate Room Session"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* STREAM CATEGORIES MANAGER CARD */}
          <div className="bg-neutral-900 border border-white/5 rounded-3xl p-6 shadow-xl space-y-4">
            <div>
              <h3 className="font-extrabold text-white text-base tracking-tight flex items-center gap-2">
                <Database className="w-5 h-5 text-orange-400" />
                Manage Stream Categories
              </h3>
              <p className="text-xs text-neutral-550">Rename your directories or clear empty classification mappings on-the-fly</p>
            </div>

            <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1 flex flex-col gap-1.5">
              {Array.from(new Set(streams.map(s => s.category || "Uncategorized"))).length === 0 ? (
                <p className="text-xs text-neutral-600 italic text-center py-4">No categories directory indexes available.</p>
              ) : (
                Array.from(new Set(streams.map(s => s.category || "Uncategorized"))).map((catName) => (
                  <div key={catName} className="p-3 bg-neutral-950 rounded-2xl border border-white/5 flex flex-col gap-2.5 text-xs">
                    <div className="flex items-center justify-between gap-4">
                      {editingCategory === catName ? (
                        <div className="flex gap-2 w-full">
                          <input
                            type="text"
                            value={newCategoryName}
                            onChange={(e) => setNewCategoryName(e.target.value)}
                            className="bg-neutral-900 border border-white/10 rounded-xl px-2 py-1.5 text-xs text-white flex-1 focus:outline-none focus:border-orange-500"
                            placeholder="New category name"
                          />
                          <button
                            onClick={() => {
                              if (!newCategoryName.trim()) return;
                              fetch("/api/admin/categories/rename", {
                                method: "POST",
                                headers: { "Content-Type": "application/json" },
                                body: JSON.stringify({ oldName: catName, newName: newCategoryName.trim() })
                              })
                                .then(res => res.json())
                                .then((res: any) => {
                                  if (res.success) {
                                    showNotification(`Renamed to "${newCategoryName.trim()}" successfully`, "success");
                                    setEditingCategory(null);
                                    setNewCategoryName("");
                                  }
                                });
                            }}
                            className="px-2.5 py-1.5 bg-orange-500 hover:bg-orange-400 text-black font-extrabold rounded-lg text-[10px]"
                          >
                            Save
                          </button>
                          <button
                            onClick={() => setEditingCategory(null)}
                            className="px-2 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded-lg text-[10px]"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <>
                          <span className="font-extrabold text-white">{catName}</span>
                          <div className="flex gap-1.5 shrink-0">
                            <button
                              onClick={() => {
                                setEditingCategory(catName);
                                setNewCategoryName(catName);
                              }}
                              className="px-2 py-1 bg-neutral-900 hover:bg-neutral-800 border border-white/5 text-neutral-300 text-[10px] font-bold rounded"
                            >
                              Rename
                            </button>
                            <button
                              onClick={() => {
                                fetch("/api/admin/categories/delete", {
                                  method: "POST",
                                  headers: { "Content-Type": "application/json" },
                                  body: JSON.stringify({ categoryName: catName })
                                })
                                  .then(res => res.json())
                                  .then((res: any) => {
                                    if (res.success) {
                                      showNotification(`Cleared category "${catName}" mapping successfully`, "success");
                                    }
                                  });
                              }}
                              className="px-2 py-1 bg-red-950/20 hover:bg-red-650 hover:text-white text-red-500 text-[10px] font-bold rounded transition"
                            >
                              Clear
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

        </div>

      </main>

      {editingStream && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="w-full max-w-lg bg-neutral-900 border border-white/10 rounded-3xl p-6 shadow-2xl flex flex-col gap-5">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <h3 className="text-sm font-extrabold text-white flex items-center gap-2 font-mono uppercase tracking-widest text-orange-450">
                <Pencil className="w-4 h-4 text-orange-400" />
                Edit Channel Information
              </h3>
              <button 
                onClick={() => setEditingStream(null)}
                className="p-1.5 bg-neutral-800 hover:bg-neutral-750 text-neutral-400 hover:text-white rounded-lg transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleUpdateStream} className="space-y-4">
              <div className="flex flex-col gap-1.5">
                <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider">Stream/Channel Name *</label>
                <input
                  type="text"
                  required
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  placeholder="E.g., BBC One HD"
                  className="w-full bg-neutral-950 border border-white/5 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-orange-550 transition"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider">Stream Resource URL (HLS / m3u8 / mp4) *</label>
                <input
                  type="text"
                  required
                  value={editUrl}
                  onChange={(e) => setEditUrl(e.target.value)}
                  placeholder="https://example.com/stream.m3u8"
                  className="w-full bg-neutral-950 border border-white/5 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-orange-550 transition font-mono"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider">Category</label>
                <input
                  type="text"
                  value={editCategory}
                  onChange={(e) => setEditCategory(e.target.value)}
                  placeholder="E.g., News, Entertainment"
                  className="w-full bg-neutral-950 border border-white/5 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-orange-550 transition"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider">Channel Logo URL</label>
                <input
                  type="text"
                  value={editLogo}
                  onChange={(e) => setEditLogo(e.target.value)}
                  placeholder="https://example.com/logo.png"
                  className="w-full bg-neutral-950 border border-white/5 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-orange-550 transition"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingStream(null)}
                  className="flex-1 py-3 bg-neutral-800 hover:bg-neutral-750 text-neutral-300 hover:text-white font-bold rounded-xl transition text-[11px] uppercase tracking-wider"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 bg-gradient-to-r from-orange-500 to-red-600 hover:brightness-110 text-white font-extrabold rounded-xl transition shadow-lg text-[11px] uppercase tracking-wider"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
