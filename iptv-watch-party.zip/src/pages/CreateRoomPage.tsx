import React, { useState, useEffect } from "react";
import { useNavigate, useSearchParams, Link } from "react-router-dom";
import { socket } from "../lib/socket";
import { StreamItem } from "../types";
import { ChevronLeft, Projector, Shield, Users, Layers, Info, ListPlus } from "lucide-react";

export default function CreateRoomPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  // Prefill fields from URL query variables (if redirected from watch/launch direct directory buttons)
  const initialUrl = searchParams.get("url") || "";
  const initialName = searchParams.get("name") || "";

  const [availableStreams, setAvailableStreams] = useState<StreamItem[]>([]);
  const [selectedStreamId, setSelectedStreamId] = useState("");
  const [roomName, setRoomName] = useState("");
  const [mediaUrl, setMediaUrl] = useState(initialUrl);
  const [mediaName, setMediaName] = useState(initialName);
  const [isPublic, setIsPublic] = useState(true);
  const [isPasswordProtected, setIsPasswordProtected] = useState(false);
  const [password, setPassword] = useState("");
  const [syncEnabled, setSyncEnabled] = useState(true);
  const [username, setUsername] = useState(() => {
    return localStorage.getItem("iptv_username") || "";
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Fetch registered streams for pre-fill assistant dropdown
    fetch("/api/streams")
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setAvailableStreams(data);
        }
      })
      .catch(() => {});
  }, []);

  const handleStreamSelect = (streamId: string) => {
    setSelectedStreamId(streamId);
    if (!streamId) return;
    const selected = availableStreams.find(s => s.id === streamId);
    if (selected) {
      setMediaUrl(selected.url);
      setMediaName(selected.name);
      if (!roomName) {
        setRoomName(`Party: ${selected.name}`);
      }
    }
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) {
      alert("Please provide a nickname to associate as the Room Host.");
      return;
    }
    if (!mediaUrl.trim()) {
      alert("Please enter a valid video or stream (.m3u8/mp4) URL to display.");
      return;
    }

    setLoading(true);

    // Store username in storage
    localStorage.setItem("iptv_username", username.trim());

    const params = {
      name: roomName.trim() || `${username.trim()}'s Theater`,
      mediaUrl: mediaUrl.trim(),
      mediaName: mediaName.trim() || "Dynamic Video Channel",
      public: isPublic,
      password: isPasswordProtected && password.trim() ? password.trim() : undefined,
      syncEnabled,
      username: username.trim()
    };

    socket.emit("create_room", params, (response: any) => {
      setLoading(false);
      if (response && response.success) {
        navigate(`/room/${response.roomId}`);
      } else {
        alert("Failed to establish server room container.");
      }
    });
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans selection:bg-orange-500 pb-12">
      
      {/* Header */}
      <header id="iptv_streams_navbar" className="px-8 border-b border-white/10 flex flex-col md:flex-row items-center justify-between bg-black/40 backdrop-blur-md sticky top-0 z-50 py-4 md:py-0 md:h-16 gap-4">
        <div className="flex items-center gap-8">
          <div className="text-2xl font-black tracking-tighter bg-gradient-to-r from-orange-500 to-red-600 bg-clip-text text-transparent">
            VORTEX.TV
          </div>
          <nav className="flex gap-6 text-sm font-medium text-white/60">
            <Link to="/streams" className="hover:text-white transition-colors shrink-0">STREAMS</Link>
            <Link to="/public-rooms" className="hover:text-white transition-colors shrink-0">WATCH LOBBY</Link>
            <Link to="/create-room" className="text-white border-b-2 border-orange-500 pb-4 pt-4 shrink-0">CREATE THEATER</Link>
          </nav>
        </div>

        {/* Navigator Links */}
        <div className="flex items-center gap-3">
          <Link 
            to="/streams" 
            className="flex items-center gap-2 px-3 py-1.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full text-xs text-orange-400 font-extrabold transition shadow-sm animate-fade-in"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            Cancel and Return
          </Link>
        </div>
      </header>

      {/* Main Content Layout */}
      <main className="max-w-2xl mx-auto w-full px-6 mt-10">
        <div className="bg-neutral-900 border border-white/5 rounded-3xl p-6 md:p-8 shadow-2xl relative overflow-hidden">
          
          <div className="flex items-center gap-3 mb-6 relative z-10">
            <div className="p-3 bg-orange-500/10 text-orange-400 border border-orange-500/20 rounded-xl">
              <Projector className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl md:text-2xl font-black text-white tracking-tight">Sync New Watch Party Room</h2>
              <p className="text-xs text-neutral-400">Assemble friends to view fully synchronized live streams and participate in real-time chats.</p>
            </div>
          </div>

          <form onSubmit={handleCreate} className="space-y-5 relative z-10">
            
            {/* Host Identity nickname assignment */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-bold text-neutral-400 uppercase tracking-wider">Your Host Nickname *</label>
              <input
                type="text"
                required
                maxLength={20}
                value={username}
                onChange={(e) => setUsername(e.target.value.replace(/[^a-zA-Z0-9_]/g, ""))}
                placeholder="Enter nickname (letters, numbers, _)"
                className="w-full bg-neutral-950 border border-white/5 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-orange-550 transition"
              />
            </div>

            {/* Stream Pre-fill Dropdown */}
            {availableStreams.length > 0 && (
              <div className="flex flex-col gap-1.5 bg-neutral-950 p-4 border border-white/5 rounded-2xl">
                <label className="text-xs font-bold text-orange-400 uppercase tracking-widest flex items-center gap-1.5">
                  <ListPlus className="w-4 h-4 text-orange-400" />
                  Quick Fill from Streams Catalog
                </label>
                <select
                  value={selectedStreamId}
                  onChange={(e) => handleStreamSelect(e.target.value)}
                  className="w-full bg-neutral-900 border border-white/5 rounded-lg px-3 py-2 text-xs text-neutral-200 focus:outline-none focus:border-orange-500"
                >
                  <option value="">-- Choose a Stream from catalog (Optional) --</option>
                  {availableStreams.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.name} ({item.category || "Uncategorized"})
                    </option>
                  ))}
                </select>
                <p className="text-[10px] text-neutral-500">Choosing a stream will instantly fill the URL and Display Title below.</p>
              </div>
            )}

            {/* Room Name setting */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-bold text-neutral-400 uppercase tracking-wider">Room Title</label>
              <input
                type="text"
                value={roomName}
                onChange={(e) => setRoomName(e.target.value)}
                placeholder="E.g., Friday Film Club"
                className="w-full bg-neutral-950 border border-white/5 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-orange-550 transition"
              />
            </div>

            {/* Stream media address */}
            <div className={`grid grid-cols-1 ${(!selectedStreamId && !initialUrl) ? "md:grid-cols-2" : ""} gap-4`}>
              {!selectedStreamId && !initialUrl && (
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-neutral-400 uppercase tracking-wider">Stream URL (.m3u8 or .mp4) *</label>
                  <input
                    type="text"
                    required
                    value={mediaUrl}
                    onChange={(e) => setMediaUrl(e.target.value)}
                    placeholder="https://example.com/playlist.m3u8"
                    className="w-full bg-neutral-950 border border-white/5 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-orange-550 transition"
                  />
                </div>
              )}

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-neutral-400 uppercase tracking-wider">Display Title for Video</label>
                <input
                  type="text"
                  value={mediaName}
                  onChange={(e) => setMediaName(e.target.value)}
                  placeholder="E.g., Sintel Movie Stream"
                  className="w-full bg-neutral-950 border border-white/5 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-orange-550 transition"
                />
              </div>
            </div>

            {/* Toggles Container */}
            <div className="bg-neutral-950 p-4 rounded-2xl border border-white/5 flex flex-col gap-4">
              
              {/* Sync Playback authorized control */}
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-start gap-2.5">
                  <Layers className="w-5 h-5 text-orange-400 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-bold text-neutral-200">Authoritative Synchronization</h4>
                    <p className="text-[11px] text-neutral-500">Enable absolute real-time state sync. Media plays, pauses, are locked to the host.</p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer select-none">
                  <input 
                    type="checkbox" 
                    checked={syncEnabled} 
                    onChange={(e) => setSyncEnabled(e.target.checked)} 
                    className="sr-only peer" 
                  />
                  <div className="w-9 h-5 bg-neutral-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-neutral-400 after:border-neutral-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-orange-500 peer-checked:after:bg-neutral-950"></div>
                </label>
              </div>

              <hr className="border-white/5" />

              {/* Room Public status toggle */}
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-start gap-2.5">
                  <Users className="w-5 h-5 text-orange-400 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-bold text-neutral-200">Public visibility</h4>
                    <p className="text-[11px] text-neutral-500">Show this theater on the public active watch parties dashboard index.</p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer select-none">
                  <input 
                    type="checkbox" 
                    checked={isPublic} 
                    onChange={(e) => setIsPublic(e.target.checked)} 
                    className="sr-only peer" 
                  />
                  <div className="w-9 h-5 bg-neutral-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-neutral-400 after:border-neutral-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-orange-500 peer-checked:after:bg-neutral-950"></div>
                </label>
              </div>

              <hr className="border-white/5" />

              {/* Room Password toggler */}
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-start gap-2.5">
                  <Shield className="w-5 h-5 text-orange-400 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-bold text-neutral-200">Password protection</h4>
                    <p className="text-[11px] text-neutral-500">Require an access password so that only authorized guests can enter.</p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer select-none">
                  <input 
                    type="checkbox" 
                    checked={isPasswordProtected} 
                    onChange={(e) => setIsPasswordProtected(e.target.checked)} 
                    className="sr-only peer" 
                  />
                  <div className="w-9 h-5 bg-neutral-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-neutral-400 after:border-neutral-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-orange-500 peer-checked:after:bg-neutral-950"></div>
                </label>
              </div>

              {isPasswordProtected && (
                <div className="flex flex-col gap-1.5 pt-2 animate-fade-in">
                  <label className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider flex items-center gap-1">
                    <Shield className="w-3.5 h-3.5 text-orange-500" />
                    Enter Custom Door Password (Required for entry)
                  </label>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="E.g., 12345"
                    className="w-full bg-neutral-950 border border-white/5 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-orange-500"
                  />
                </div>
              )}
            </div>

            {/* Submission triggers */}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-4 bg-gradient-to-r from-orange-500 to-red-600 hover:brightness-110 text-white font-extrabold rounded-xl transition shadow-lg flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              {loading ? "Generating Theatre..." : "Create and Join Live Room"}
            </button>

            <div className="flex items-center gap-2 text-[11px] text-neutral-500 mt-2">
              <Info className="w-4 h-4 shrink-0 text-neutral-600" />
              <span>Inactive or vacant rooms are monitored and recycled automatically by the global server sweep engine after 4 idle hours.</span>
            </div>

          </form>
        </div>
      </main>
    </div>
  );
}
