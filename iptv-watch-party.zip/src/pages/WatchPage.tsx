import { useEffect, useState } from "react";
import { useSearchParams, useNavigate, Link } from "react-router-dom";
import StreamPlayer from "../components/StreamPlayer";
import StreamChat from "../components/StreamChat";
import { 
  ChevronLeft, Volume2, Info, Search, List, Play, Radio, Wifi, Database
} from "lucide-react";
import { StreamItem } from "../types";

export default function WatchPage() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  // Current active stream details extracted from query parameters
  const url = searchParams.get("url") || "";
  const id = searchParams.get("id") || "global";
  const name = searchParams.get("name") || "IPTV Playback";
  const logo = searchParams.get("logo") || "";

  // IPTV Streams Catalog switcher states
  const [streams, setStreams] = useState<StreamItem[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [showGuide, setShowGuide] = useState(true);

  useEffect(() => {
    // Fetch registered channels for the EPG guide
    fetch("/api/streams")
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setStreams(data);
        }
      })
      .catch(() => {});
  }, []);

  // Compute Categories from streams list
  const categories = ["All", ...Array.from(new Set(streams.map(s => s.category || "Uncategorized")))];

  // Filtered streams matching criteria
  const filteredStreams = streams.filter(stream => {
    const matchesSearch = stream.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          (stream.category || "").toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "All" || stream.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleSwitchChannel = (s: StreamItem) => {
    setSearchParams({
      url: s.url,
      id: s.id,
      name: s.name,
      logo: s.logo || ""
    });
  };

  if (!url) {
    return (
      <div className="min-h-screen bg-neutral-950 flex flex-col items-center justify-center text-center p-6 text-neutral-100 font-sans">
        <h3 className="text-xl font-bold">No active stream URL specified</h3>
        <button 
          onClick={() => navigate("/streams")}
          className="mt-4 px-5 py-2.5 bg-orange-500 text-neutral-950 font-extrabold rounded-xl hover:bg-orange-400 transition"
        >
          Return to Streams Directory
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans select-none">
      
      {/* Sleek IPTV Portal Header */}
      <header className="px-6 py-4 bg-black/45 backdrop-blur-md border-b border-white/10 sticky top-0 z-50 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link
            to="/streams"
            className="p-2.5 bg-neutral-900 hover:bg-neutral-800 border border-white/5 rounded-xl text-neutral-300 hover:text-white transition"
            title="Go back to IPTV indexes"
          >
            <ChevronLeft className="w-5 h-5" />
          </Link>
          <div className="flex items-center gap-3">
            {logo && (
              <img 
                src={logo} 
                alt={name}
                referrerPolicy="no-referrer"
                className="w-8 h-8 rounded bg-neutral-900 border border-white/5 object-cover"
              />
            )}
            <div>
              <h2 className="text-sm font-extrabold tracking-tight text-white flex items-center gap-2">
                {name}
                <span className="text-[9px] bg-red-650 text-white font-black px-1.5 py-0.2 rounded uppercase tracking-wider">LIVE</span>
              </h2>
              <span className="text-[10px] text-orange-400 font-semibold uppercase tracking-wider flex items-center gap-1 mt-0.5">
                <span className="w-1.5 h-1.5 rounded-full bg-orange-400 animate-pulse"></span>
                IPTV Interactive Player mode
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowGuide(!showGuide)}
            className="flex items-center gap-2 px-3 py-1.5 bg-neutral-900 hover:bg-neutral-800 border border-white/5 rounded-xl text-xs font-bold text-neutral-300 hover:text-white transition cursor-pointer"
          >
            <List className="w-4 h-4 text-orange-400" />
            {showGuide ? "Hide Channel Guide" : "Show Channel Guide"}
          </button>
        </div>
      </header>

      {/* Main Panel layout: Sidebar Switcher + Center Video Player + Right Chat */}
      <div className="flex-1 w-full p-4 lg:p-6 grid grid-cols-1 xl:grid-cols-12 gap-5 h-[calc(100vh-76px)] overflow-hidden">
        
        {/* Left Column (xl:col-span-3): IPTV Channel switched sidebar */}
        <div className={`${showGuide ? "xl:col-span-3 flex flex-col gap-3 rounded-2xl border border-white/5 p-4 overflow-hidden bg-neutral-900" : "hidden"}`}>
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-extrabold text-white flex items-center gap-1.5">
              <List className="w-4 h-4 text-orange-400" />
              IPTV Channel Guide
            </h3>
            <span className="text-[10px] bg-neutral-950 border border-white/5 px-2 py-0.5 rounded text-neutral-400 font-mono">
              Channels: {filteredStreams.length}
            </span>
          </div>

          {/* Search channel */}
          <div className="relative">
            <Search className="absolute left-3 top-3 w-3.5 h-3.5 text-neutral-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter channels..."
              className="w-full bg-neutral-950 border border-white/5 rounded-lg pl-8 pr-3 py-2 text-xs text-white placeholder:text-neutral-600 focus:outline-none focus:border-orange-500 transition"
            />
          </div>

          {/* Category Filter Pills (Horizontal Scroll) */}
          <div className="flex gap-1 overflow-x-auto pb-1.5 scrollbar-thin scrollbar-thumb-neutral-800">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-2.5 py-1 rounded text-[10px] font-bold uppercase tracking-wider shrink-0 transition ${
                  selectedCategory === cat
                    ? "bg-orange-500 text-black"
                    : "bg-neutral-950 border border-white/5 text-neutral-400 hover:text-white"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Interactive Streams Directory List */}
          <div className="flex-1 overflow-y-auto space-y-1.5 pr-0.5">
            {filteredStreams.length === 0 ? (
              <p className="text-xs text-neutral-600 italic text-center py-8">No matching channels found.</p>
            ) : (
              filteredStreams.map(s => {
                const isCurrent = s.url === url;
                const isOffline = s.status === "offline";
                return (
                  <button
                    key={s.id}
                    onClick={() => handleSwitchChannel(s)}
                    className={`w-full text-left p-2 rounded-xl border flex items-center gap-2.5 transition ${
                      isCurrent
                        ? "bg-orange-500/10 border-orange-500/30 text-white"
                        : "bg-neutral-950/45 border-white/5 hover:border-white/10 text-neutral-300"
                    }`}
                  >
                    {/* Logo */}
                    <div className="w-8 h-8 rounded bg-neutral-900 border border-white/5 overflow-hidden shrink-0 relative flex items-center justify-center">
                      {s.logo ? (
                        <img 
                          src={s.logo} 
                          alt={s.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <Play className="w-3.5 h-3.5 text-neutral-500" />
                      )}
                    </div>

                    <div className="truncate flex-1 min-w-0">
                      <div className="flex items-center gap-1 justify-between">
                        <span className="text-[11px] font-extrabold truncate block text-neutral-100">{s.name}</span>
                        {isOffline && (
                          <span className="text-[7.5px] bg-red-650 text-white font-bold px-0.5 rounded tracking-wide shrink-0">OFF</span>
                        )}
                      </div>
                      <span className="text-[9px] text-neutral-500 font-mono block truncate">{s.category || "General"}</span>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Center Column (xl:col-span-6): Video stream player + Analytics cards */}
        <div className={`${showGuide ? "xl:col-span-6" : "xl:col-span-9"} flex flex-col gap-4 overflow-y-auto pr-1`}>
          <StreamPlayer 
            url={url} 
            isPlaying={true} 
            isHost={false} 
            syncEnabled={false} 
          />

          {/* Description details Card */}
          <div className="bg-neutral-900 border border-white/5 rounded-2xl p-4 flex flex-col gap-3">
            <h3 className="font-extrabold text-white text-xs flex items-center gap-2 uppercase tracking-wider">
              <Info className="w-4 h-4 text-orange-450" />
              Direct IPTV Playback Details
            </h3>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Connected stream: <span className="font-bold text-neutral-200">"{name}"</span>. Switching channels on-the-fly alters the live spectator feed in your chat window but does not interrupt other users.
            </p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-1.5">
              <div className="bg-neutral-950 p-2.5 rounded-xl border border-white/5">
                <span className="text-[9px] text-neutral-550 uppercase tracking-widest block font-bold">Category</span>
                <span className="text-[11px] font-semibold text-neutral-300 truncate block">
                  {streams.find(s => s.url === url)?.category || "IPTV Live"}
                </span>
              </div>
              <div className="bg-neutral-950 p-2.5 rounded-xl border border-white/5">
                <span className="text-[9px] text-neutral-555 uppercase tracking-widest block font-bold">Latency</span>
                <span className="text-[11px] font-semibold text-neutral-300">Live Adaptive</span>
              </div>
              <div className="bg-neutral-950 p-2.5 rounded-xl border border-white/5">
                <span className="text-[9px] text-neutral-555 uppercase tracking-widest block font-bold">Status</span>
                <span className="text-[11px] font-black text-emerald-400 flex items-center gap-1 uppercase">
                  <Wifi className="w-3 h-3 text-emerald-400" /> Online
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (xl:col-span-3): Stream-Specific Shared Live Chat */}
        <div className="xl:col-span-3 h-full flex flex-col overflow-hidden">
          <StreamChat roomId={`chat:stream:${id}`} />
        </div>

      </div>
    </div>
  );
}
