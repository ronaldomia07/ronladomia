import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { socket } from "../lib/socket";
import { Tv, Users, ChevronLeft, ArrowRight, Play, Loader, ShieldAlert } from "lucide-react";

interface PublicRoomItem {
  id: string;
  name: string;
  userCount: number;
  mediaUrl: string;
  mediaName: string;
  isPlaying: boolean;
  syncEnabled: boolean;
}

export default function PublicRoomsPage() {
  const [rooms, setRooms] = useState<PublicRoomItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Initial bootstrap REST
    fetch("/api/public-rooms")
      .then(res => res.json())
      .then(data => {
        setRooms(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));

    // Live socket broadcasts
    const handleRoomsUpdate = (list: PublicRoomItem[]) => {
      setRooms(list);
    };

    socket.on("public_rooms_update", handleRoomsUpdate);

    return () => {
      socket.off("public_rooms_update", handleRoomsUpdate);
    };
  }, []);

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans selection:bg-orange-500 pb-12">
      
      {/* Header */}
      <header id="iptv_streams_navbar" className="px-8 border-b border-white/10 flex flex-col md:flex-row items-center justify-between bg-black/40 backdrop-blur-md sticky top-0 z-50 py-4 md:py-0 md:h-16 gap-4">
        <div className="flex items-center gap-8">
          <div className="text-2xl font-black tracking-tighter bg-gradient-to-r from-orange-500 to-red-600 bg-clip-text text-transparent">
            VORTEX.TV
          </div>
          <nav className="flex gap-6 text-sm font-medium text-white/60">
            <Link to="/streams" className="hover:text-white transition-colors shrink-0">STREAMS</Link>
            <Link to="/public-rooms" className="text-white border-b-2 border-orange-500 pb-4 pt-4 shrink-0">WATCH LOBBY</Link>
            <Link to="/create-room" className="hover:text-white transition-colors shrink-0">CREATE THEATER</Link>
          </nav>
        </div>

        {/* Navigator Links */}
        <div className="flex items-center gap-3">
          <Link 
            to="/streams" 
            className="flex items-center gap-2 px-3 py-1.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full text-xs text-orange-400 font-extrabold transition shadow-sm"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            Streams Catalog
          </Link>
        </div>
      </header>

      <main className="max-w-5xl mx-auto w-full px-6 mt-10">
        
        {/* Quick Join Container */}
        <div id="quick_join_card" className="bg-neutral-900 border border-white/5 rounded-3xl p-5 mb-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="p-3 bg-orange-500/10 text-orange-400 border border-orange-500/20 rounded-xl">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white leading-normal">Have a Room Code?</h3>
              <p className="text-xs text-neutral-400">Enter a private or public room code below to synchronize and enter watch parties.</p>
            </div>
          </div>
          <form 
            onSubmit={(e) => {
              e.preventDefault();
              const code = (e.currentTarget.elements.namedItem("roomCode") as HTMLInputElement).value.trim().toUpperCase();
              if (code) {
                window.location.hash = `/room/${code}`;
              }
            }} 
            className="flex items-center gap-2 w-full sm:w-auto"
          >
            <input
              name="roomCode"
              type="text"
              required
              maxLength={6}
              placeholder="A7B9K2"
              className="bg-neutral-950 border border-white/5 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-orange-500 placeholder:text-neutral-600 font-mono tracking-widest text-center w-full sm:w-40 uppercase"
            />
            <button
              type="submit"
              className="px-5 py-2.5 bg-gradient-to-r from-orange-500 to-red-600 hover:brightness-110 text-white font-extrabold rounded-xl text-xs tracking-wide transition shrink-0 cursor-pointer"
            >
              Join Room
            </button>
          </form>
        </div>

        {/* Intro */}
        <div className="mb-8 flex flex-col gap-1">
          <h2 className="text-2xl font-black text-white tracking-tight">Active Public Watch Rooms</h2>
          <p className="text-sm text-neutral-400">Discover ongoing synchronized broadcasts and join chat rooms hosted by developers globally.</p>
        </div>

        {loading ? (
          <div className="py-24 flex flex-col items-center justify-center">
            <Loader className="w-8 h-8 text-orange-400 animate-spin" />
            <p className="text-xs text-neutral-500 mt-2">Refreshing live catalogs...</p>
          </div>
        ) : rooms.length === 0 ? (
          <div className="py-20 border border-white/5 rounded-3xl text-center bg-neutral-900/15 p-6 flex flex-col items-center justify-center gap-4">
            <Tv className="w-12 h-12 text-neutral-700 animate-bounce" />
            <div>
              <h4 className="font-extrabold text-neutral-300">No public parties active</h4>
              <p className="text-xs text-neutral-500 max-w-sm mt-1">
                Be the pioneer host! Click below to synchronize your HLS IPTV video address and invite peers instantly.
              </p>
            </div>
            <Link 
              to="/create-room"
              className="px-5 py-2.5 bg-gradient-to-r from-orange-500 to-red-600 hover:brightness-110 text-white font-black rounded-lg text-xs tracking-wide transition shadow-md"
            >
              Start New Watch Room
            </Link>
          </div>
        ) : (
          <div id="public_theater_list" className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {rooms.map((room) => (
              <div 
                key={room.id}
                id={`room_card_${room.id}`}
                className="bg-neutral-900 border border-white/5 rounded-3xl p-5 hover:border-white/10 hover:shadow-xl transition flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex justify-between items-start gap-4">
                    <div>
                      <h3 className="font-black text-white text-base tracking-tight leading-snug">{room.name}</h3>
                      <span className="text-[10px] text-orange-400 font-bold uppercase tracking-widest mt-0.5 block font-mono">ID: {room.id}</span>
                    </div>
                    
                    <div className="flex items-center gap-1.5 bg-neutral-950 px-3 py-1 rounded-full border border-white/5 text-neutral-300 text-[11px] font-mono shrink-0">
                      <Users className="w-3.5 h-3.5 text-orange-400" />
                      <span>{room.userCount} inside</span>
                    </div>
                  </div>

                  <div className="bg-neutral-950 p-3.5 rounded-2xl border border-white/5 flex flex-col gap-1.5 text-xs">
                    <span className="text-[10px] text-neutral-500 uppercase tracking-widest font-extrabold">Active Playback Broadcast</span>
                    <h4 className="font-semibold text-neutral-300 truncate" title={room.mediaName}>{room.mediaName}</h4>
                    <p className="truncate text-[10px] text-neutral-500 font-mono mt-0.5">{room.mediaUrl}</p>
                  </div>
                </div>

                <div className="mt-5 flex items-center justify-between border-t border-white/5 pt-3.5 flex-wrap gap-2">
                  <div className="flex gap-2">
                    <span className="px-2 py-0.5 bg-neutral-800 text-neutral-400 rounded text-[9px] font-bold uppercase">
                      {room.isPlaying ? "Playing" : "Paused"}
                    </span>
                    <span className="px-2 py-0.5 bg-neutral-800 text-neutral-400 rounded text-[9px] font-bold uppercase">
                      Sync: Enabled
                    </span>
                  </div>

                  <Link
                    to={`/room/${room.id}`}
                    className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-orange-500 to-red-600 hover:brightness-110 text-white text-xs font-black rounded-lg transition shadow"
                  >
                    Enter Room
                    <ArrowRight className="w-3.5 h-3.5 text-white" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
