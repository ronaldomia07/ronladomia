import React, { useEffect, useState, useRef } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { socket } from "../lib/socket";
import { Room, User } from "../types";
import StreamPlayer from "../components/StreamPlayer";
import StreamChat from "../components/StreamChat";
import { 
  Crown, Users, Copy, ChevronLeft, ShieldAlert, 
  Settings, KeyRound, Unlock, Loader, Sparkles, Radio, List
} from "lucide-react";

export default function RoomPage() {
  const { id: roomId } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [room, setRoom] = useState<Room | null>(null);
  const [errorText, setErrorText] = useState("");
  const [passwordInput, setPasswordInput] = useState("");
  const [passwordRequired, setPasswordRequired] = useState(false);
  const [username, setUsername] = useState(() => {
    return localStorage.getItem("iptv_username") || "";
  });
  const [usernameInput, setUsernameInput] = useState("");
  const [showUsernameModal, setShowUsernameModal] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  
  // Local host check
  const [isHost, setIsHost] = useState(false);
  const [tabIndex, setTabIndex] = useState<"chat" | "users">("chat");

  const [followHostSync, setFollowHostSync] = useState(true);
  const [hostPasswordInput, setHostPasswordInput] = useState("");
  const [addPlaylistItemName, setAddPlaylistItemName] = useState("");
  const [addPlaylistItemUrl, setAddPlaylistItemUrl] = useState("");

  const [streams, setStreams] = useState<any[]>([]);
  const [showRoomGuide, setShowRoomGuide] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");

  const syncTimerRef = useRef<any>(null);

  // Join Room gateway
  useEffect(() => {
    if (!roomId) return;

    if (!username) {
      setShowUsernameModal(true);
      return;
    }

    // Fetch registered channels for sidebar EPG guide
    fetch("/api/streams")
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setStreams(data);
        }
      })
      .catch(() => {});

    // Try joining
    triggerJoin();

    // Setup general socket handlers for state mutations
    const handleRoomState = (freshRoom: Room) => {
      setRoom(freshRoom);
      // Double check if local socket is the current room host
      setIsHost(freshRoom.hostId === socket.id);
    };

    const handleUserJoined = (user: { socketId: string; username: string; isHost: boolean }) => {
      setRoom(prev => {
        if (!prev) return null;
        const exists = prev.users.some(u => u.socketId === user.socketId);
        const updatedUsers = exists 
          ? prev.users.map(u => u.socketId === user.socketId ? { ...u, isHost: user.isHost } : u)
          : [...prev.users, { socketId: user.socketId, username: user.username, isHost: user.isHost }];
        return { ...prev, users: updatedUsers };
      });
    };

    const handleUserLeft = (data: { socketId: string; username: string ; kicked?: boolean; blocked?: boolean }) => {
      setRoom(prev => {
        if (!prev) return null;
        return {
          ...prev,
          users: prev.users.filter(u => u.socketId !== data.socketId)
        };
      });
    };

    const handleNewHost = (host: { socketId: string; username: string }) => {
      setIsHost(host.socketId === socket.id);
      setRoom(prev => {
        if (!prev) return null;
        return {
          ...prev,
          hostId: host.socketId,
          users: prev.users.map(u => ({
            ...u,
            isHost: u.socketId === host.socketId
          }))
        };
      });
    };

    const handleDeleted = () => {
      alert("This Watch Party Room has expired or was disbanded.");
      navigate("/streams");
    };

    const handleSelfKicked = () => {
      alert("You have been kicked by the room administrator.");
      navigate("/streams");
    };

    const handleSelfBlocked = () => {
      alert("Your membership has been blacklisted from entry into this room.");
      navigate("/streams");
    };

    socket.on("room_state", handleRoomState);
    socket.on("user_joined", handleUserJoined);
    socket.on("user_left", handleUserLeft);
    socket.on("new_host", handleNewHost);
    socket.on("room_deleted", handleDeleted);
    socket.on("kicked", handleSelfKicked);
    socket.on("blocked", handleSelfBlocked);

    return () => {
      socket.off("room_state", handleRoomState);
      socket.off("user_joined", handleUserJoined);
      socket.off("user_left", handleUserLeft);
      socket.off("new_host", handleNewHost);
      socket.off("room_deleted", handleDeleted);
      socket.off("kicked", handleSelfKicked);
      socket.off("blocked", handleSelfBlocked);
      
      // Cleanup heartbeat syncing
      if (syncTimerRef.current) {
        clearInterval(syncTimerRef.current);
      }
      
      // Notify server we have left this specific room
      socket.emit("leave_room", { roomId });
    };
  }, [roomId, username]);

  // Host Authority Heartbeat interval
  useEffect(() => {
    if (isHost && room) {
      // Setup periodic status sync_state broadcast every 2 seconds
      syncTimerRef.current = setInterval(() => {
        const video = document.querySelector("video");
        if (video) {
          socket.emit("sync_state", {
            roomId: room.id,
            currentTime: video.currentTime,
            isPlaying: !video.paused
          });
        }
      }, 2000);
    } else {
      if (syncTimerRef.current) {
        clearInterval(syncTimerRef.current);
      }
    }

    return () => {
      if (syncTimerRef.current) {
        clearInterval(syncTimerRef.current);
      }
    };
  }, [isHost, room?.id]);

  useEffect(() => {
    if (room && isHost) {
      setHostPasswordInput(room.password || "");
    }
  }, [room?.password, isHost]);

  const triggerJoin = () => {
    setErrorText("");
    socket.emit("join_room", { 
      roomId, 
      username, 
      password: passwordInput ? passwordInput.trim() : undefined 
    }, (res: any) => {
      if (res && res.success) {
        setRoom(res.room);
        setPasswordRequired(false);
        setIsHost(res.room.hostId === socket.id);
      } else {
        if (res?.error?.includes("password")) {
          setPasswordRequired(true);
        } else {
          setErrorText(res?.error || "Unable to join room.");
        }
      }
    });
  };

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    triggerJoin();
  };

  const handleUsernameSetupSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanNick = usernameInput.trim();
    if (cleanNick) {
      setUsername(cleanNick);
      localStorage.setItem("iptv_username", cleanNick);
      setShowUsernameModal(false);
    }
  };

  // Moderation triggers (Host only)
  const handleKickUser = (targetSocketId: string) => {
    if (!room || !isHost) return;
    socket.emit("kick_user", { roomId: room.id, targetSocketId });
  };

  const handleBlockUserByUsername = (targetUsername: string) => {
    if (!room || !isHost) return;
    socket.emit("block_user", { roomId: room.id, targetUsername });
  };

  const copyInviteToClipboard = () => {
    const inviteUrl = window.location.href;
    navigator.clipboard.writeText(inviteUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  // Synchronizers emitting back to peer sockets
  const handleHostPlay = (time: number) => {
    if (!room || !isHost) return;
    socket.emit("play", { roomId: room.id, currentTime: time });
  };

  const handleHostPause = (time: number) => {
    if (!room || !isHost) return;
    socket.emit("pause", { roomId: room.id, currentTime: time });
  };

  const handleHostSeek = (time: number) => {
    if (!room || !isHost) return;
    socket.emit("seek", { roomId: room.id, currentTime: time });
  };

  const syncGuestState = () => {
    if (!room) return;
    // Seek to current room time directly
    const video = document.querySelector("video");
    if (video) {
      video.currentTime = room.currentTime;
      if (room.isPlaying) {
        video.play().catch(() => {});
      } else {
        video.pause();
      }
    }
  };

  // ------------------------------------------------------------
  // Render Gateways (Password, Onboarding, Errors, or Main Platform)
  // ------------------------------------------------------------

  if (showUsernameModal || !username) {
    return (
      <div className="min-h-screen bg-neutral-950 flex flex-col items-center justify-center p-6 text-neutral-100 font-sans selection:bg-orange-500">
        <div className="w-full max-w-md bg-neutral-900 border border-white/5 rounded-3xl p-6 md:p-8 shadow-2xl flex flex-col gap-6">
          <div className="flex flex-col items-center gap-2">
            <div className="p-3 bg-orange-500/10 text-orange-400 border border-orange-500/20 rounded-2xl animate-pulse">
              <Users className="w-8 h-8" />
            </div>
            <h3 className="font-extrabold text-white text-xl tracking-tight mt-1">Set Nickname to Enter</h3>
            <p className="text-xs text-neutral-400/90 text-center leading-relaxed">
              Before entering this collaborative watch party, choose a visual nickname so attendees can see you in the active roster list.
            </p>
          </div>
          <form onSubmit={handleUsernameSetupSubmit} className="space-y-4">
            <input
              type="text"
              required
              maxLength={15}
              value={usernameInput}
              onChange={(e) => setUsernameInput(e.target.value.replace(/[^a-zA-Z0-9_]/g, ""))}
              placeholder="Nickname (letters, numbers, _)"
              className="w-full bg-neutral-950 border border-white/10 rounded-xl px-4 py-3.5 text-center text-sm text-white font-bold focus:outline-none focus:border-orange-500/50 transition"
            />
            <button
              type="submit"
              className="w-full py-3.5 bg-gradient-to-r from-orange-500 to-red-600 text-white font-black rounded-xl transition shadow-lg text-sm uppercase tracking-wider hover:brightness-110 cursor-pointer"
            >
              Onboard Profile
            </button>
            <Link to="/streams" className="block text-center text-xs text-neutral-500 hover:text-white transition">
              Cancel and Return
            </Link>
          </form>
        </div>
      </div>
    );
  }

  if (passwordRequired) {
    return (
      <div className="min-h-screen bg-neutral-950 flex flex-col items-center justify-center p-6 text-neutral-100 font-sans selection:bg-teal-500">
        <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-3xl p-6 md:p-8 shadow-2xl flex flex-col gap-5">
          <div className="flex flex-col items-center gap-2">
            <div className="p-3 bg-yellow-500/10 text-yellow-500 border border-yellow-500/20 rounded-2xl">
              <KeyRound className="w-8 h-8" />
            </div>
            <h3 className="font-extrabold text-white text-xl tracking-tight mt-1">Room Password Protected</h3>
            <p className="text-xs text-neutral-500 text-center">
              The host of this theater has set visibility permissions to private. Please enter the correct password to bypass the gate.
            </p>
          </div>
          <form onSubmit={handlePasswordSubmit} className="space-y-4">
            <input
              type="password"
              required
              value={passwordInput}
              onChange={(e) => setPasswordInput(e.target.value)}
              placeholder="Enter Room Password"
              className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-3.5 text-center text-sm text-white font-mono focus:outline-none focus:border-yellow-500 transition"
            />
            <button
              type="submit"
              className="w-full py-3.5 bg-yellow-500 hover:bg-yellow-400 text-neutral-950 font-bold rounded-xl transition shadow-lg text-xs uppercase tracking-widest"
            >
              Verify Passcode
            </button>
            <Link to="/streams" className="block text-center text-xs text-neutral-500 hover:text-white transition">
              Go back to Stream Collection
            </Link>
          </form>
        </div>
      </div>
    );
  }

  if (errorText) {
    return (
      <div className="min-h-screen bg-neutral-950 flex flex-col items-center justify-center p-6 text-neutral-100 font-sans">
        <div className="max-w-md w-full bg-neutral-900 border border-neutral-800 rounded-3xl p-6 text-center shadow-xl space-y-4">
          <ShieldAlert className="w-12 h-12 text-red-500 mx-auto animate-bounce" />
          <h3 className="text-lg font-extrabold">Room Entry Restricted</h3>
          <p className="text-sm text-neutral-400 leading-relaxed">{errorText}</p>
          <button
            onClick={() => navigate("/streams")}
            className="w-full py-3 bg-neutral-800 hover:bg-neutral-700 text-white rounded-xl transition font-semibold text-xs"
          >
            Back to Directory
          </button>
        </div>
      </div>
    );
  }

  if (!room) {
    return (
      <div className="min-h-screen bg-neutral-950 flex flex-col items-center justify-center p-6 text-neutral-100 font-sans">
        <Loader className="w-10 h-10 text-orange-400 animate-spin" />
        <p className="text-sm text-neutral-400 mt-3 font-semibold">Connecting to theater session...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans">
      
      {/* Sync Party Station Header */}
      <header className="px-6 py-4 bg-black/40 backdrop-blur-md border-b border-white/10 sticky top-0 z-40 flex flex-wrap items-center justify-between gap-4">
        
        <div className="flex items-center gap-4">
          <Link
            to="/streams"
            className="p-2 bg-neutral-900 hover:bg-neutral-800 border border-white/5 rounded-xl text-neutral-400 hover:text-white transition"
          >
            <ChevronLeft className="w-4 h-4" />
          </Link>
          <div>
            <h2 className="text-base font-extrabold text-white tracking-tight flex items-center gap-2">
              {room.name}
              {room.password && <KeyRound className="w-3.5 h-3.5 text-yellow-500" title="Password secured" />}
            </h2>
            <div className="flex items-center gap-2 text-[10px] text-neutral-400 mt-0.5">
              <span className="flex items-center gap-1 font-bold text-orange-400 font-mono">
                <Sparkles className="w-3 h-3 text-orange-400 animate-pulse" />
                Active Party
              </span>
              <span>•</span>
              <span className="font-semibold text-neutral-300">{room.mediaName || "No Title"}</span>
            </div>
          </div>
        </div>

        {/* Lobby controls actions */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowRoomGuide(!showRoomGuide)}
            className="flex items-center gap-2 px-3 py-2 bg-neutral-900 hover:bg-neutral-800 border border-white/5 rounded-xl text-xs font-bold text-neutral-300 hover:text-white transition cursor-pointer"
          >
            <List className="w-4 h-4 text-orange-400" />
            {showRoomGuide ? "Hide Channel Guide" : "Show Channel Guide"}
          </button>

          <button
            onClick={copyInviteToClipboard}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-semibold tracking-wide transition ${
              copiedLink 
                ? "bg-emerald-500/10 border-emerald-500 text-emerald-400" 
                : "bg-neutral-900 hover:bg-neutral-800 border-white/5 text-neutral-300"
            }`}
          >
            <Copy className="w-3.5 h-3.5" />
            {copiedLink ? "Link Copied!" : "Share Room Link"}
          </button>
          
          <div className="flex items-center gap-1 bg-neutral-900 border border-white/5 px-3 py-1.5 rounded-xl text-neutral-300 text-xs font-mono">
            <Users className="w-3.5 h-3.5 text-orange-450" />
            <span>Viewers: {room.users.length}</span>
          </div>
        </div>
      </header>

      {/* Main Workspace Layout */}
      <div className="flex-1 max-w-7xl mx-auto w-full px-6 py-6 grid grid-cols-1 lg:grid-cols-12 gap-6 h-[calc(100vh-80px)] overflow-hidden">
        
        {/* Collapsible left Stream Switcher Guide */}
        <div className={`${showRoomGuide ? "lg:col-span-3 flex flex-col gap-3 rounded-2xl border border-white/5 p-4 overflow-hidden bg-neutral-900" : "hidden"}`}>
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-extrabold text-white flex items-center gap-1.5 uppercase tracking-widest font-mono">
              <Radio className="w-4 h-4 text-orange-400" />
              IPTV Channel Box
            </h3>
            <span className="text-[9px] bg-neutral-950 border border-white/5 px-2 py-0.5 rounded text-neutral-400">
              Total: {streams.filter(s => selectedCategory === "All" || s.category === selectedCategory).length}
            </span>
          </div>

          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search active feeds..."
            className="w-full bg-neutral-950 border border-white/5 rounded-xl px-3 py-2 text-xs text-white placeholder:text-neutral-600 focus:outline-none focus:border-orange-500 transition"
          />

          {/* Horizontal category chooser scrolls */}
          <div className="flex gap-1 overflow-x-auto pb-1 scrollbar-none shrink-0">
            {["All", ...Array.from(new Set(streams.map(s => s.category || "Uncategorized")))].map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider shrink-0 transition ${
                  selectedCategory === cat
                    ? "bg-orange-500 text-black"
                    : "bg-neutral-950 border border-white/5 text-neutral-400 hover:text-white"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Stream links list */}
          <div className="flex-1 overflow-y-auto space-y-1.5 pr-0.5">
            {streams.filter(s => {
              const term = searchQuery.toLowerCase();
              const matchSearch = s.name.toLowerCase().includes(term) || (s.category || "").toLowerCase().includes(term);
              const matchCat = selectedCategory === "All" || s.category === selectedCategory;
              return matchSearch && matchCat;
            }).length === 0 ? (
              <p className="text-[10px] text-neutral-500 italic text-center py-4">No matching channels.</p>
            ) : (
              streams.filter(s => {
                const term = searchQuery.toLowerCase();
                const matchSearch = s.name.toLowerCase().includes(term) || (s.category || "").toLowerCase().includes(term);
                const matchCat = selectedCategory === "All" || s.category === selectedCategory;
                return matchSearch && matchCat;
              }).map(s => {
                const isCurrent = s.url === room.mediaUrl;
                return (
                  <button
                    key={s.id}
                    onClick={() => {
                      if (isHost) {
                        socket.emit("change_room_stream", {
                          roomId: room.id,
                          name: s.name,
                          url: s.url
                        });
                      } else {
                        alert("Only the room Host is authorized to swap channels for this watch party group.");
                      }
                    }}
                    className={`w-full text-left p-2 rounded-xl border flex items-center justify-between gap-2.5 transition ${
                      isCurrent
                        ? "bg-orange-500/10 border-orange-500/30 text-white"
                        : "bg-neutral-950/45 border-white/5 hover:border-white/10 text-neutral-300"
                    }`}
                  >
                    <div className="truncate flex-1 min-w-0">
                      <span className="text-[11px] font-extrabold truncate block text-neutral-100">{s.name}</span>
                      <span className="text-[9px] text-neutral-500 font-mono block truncate">{s.category || "General"}</span>
                    </div>
                    {!isHost && (
                      <span className="p-1 bg-neutral-900 border border-white/5 rounded text-neutral-600 self-center shrink-0">🔒</span>
                    )}
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Left pane: Video View + Session Controls */}
        <div className={`${showRoomGuide ? "lg:col-span-6" : "lg:col-span-9"} flex flex-col gap-4 overflow-y-auto pr-1`}>
          
          {/* Reactive Playback Stream wrapper */}
          <StreamPlayer
            url={room.mediaUrl}
            isPlaying={room.isPlaying}
            currentTime={room.currentTime}
            isHost={isHost}
            syncEnabled={room.syncEnabled && followHostSync}
            onPlay={handleHostPlay}
            onPause={handleHostPause}
            onSeek={handleHostSeek}
          />          {/* Room state details with host overrides */}
          <div className="bg-neutral-900 border border-white/5 rounded-2xl overflow-hidden shadow-md">
            <div className="flex border-b border-white/5 bg-neutral-950/20">
              <button
                onClick={() => setTabIndex("chat")}
                className={`flex-1 py-3 text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer ${
                  tabIndex === "chat" 
                    ? "border-b-2 border-orange-500 text-orange-400 bg-black/20" 
                    : "text-neutral-400 hover:text-white"
                }`}
              >
                Room Operations & Playlist
              </button>
              <button
                onClick={() => setTabIndex("users")}
                className={`flex-1 py-3 text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer ${
                  tabIndex === "users" 
                    ? "border-b-2 border-orange-500 text-orange-400 bg-black/20" 
                    : "text-neutral-400 hover:text-white"
                }`}
              >
                Roster & Moderation ({room.users.length})
              </button>
            </div>

            <div className="p-4 font-sans">
              {tabIndex === "chat" ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between text-xs text-neutral-400">
                    <span className="font-bold uppercase tracking-wider text-neutral-500 font-mono text-[10px]">Theatre properties</span>
                    {!isHost ? (
                      <div className="flex items-center gap-4 flex-wrap">
                        <label className="flex items-center gap-1.5 cursor-pointer text-xs font-bold text-neutral-300">
                          <input
                            type="checkbox"
                            checked={followHostSync}
                            onChange={(e) => setFollowHostSync(e.target.checked)}
                            className="rounded border-white/10 bg-neutral-950 text-orange-500 focus:ring-0 cursor-pointer"
                          />
                          <span>Follow Host Sync</span>
                        </label>
                        <button 
                          onClick={syncGuestState}
                          className="text-orange-400 hover:text-orange-350 font-extrabold flex items-center gap-1 bg-orange-500/10 px-2 py-0.5 rounded transition text-[10px]"
                        >
                          <Unlock className="w-3 h-3" /> Force Join Host
                        </button>
                      </div>
                    ) : (
                      <span className="px-2 py-0.5 bg-yellow-500/15 text-yellow-500 rounded text-[9px] font-bold uppercase tracking-wider">
                        You are Host
                      </span>
                    )}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs pt-1">
                    <div className="bg-neutral-950 p-3.5 rounded-lg border border-white/5 space-y-1">
                      <span className="text-neutral-500 font-bold block uppercase text-[9px] tracking-wider">Active Stream URL</span>
                      <span className="text-white text-xs font-black block truncate">{room.mediaName || "No Name"}</span>
                      <span className="text-neutral-400 block truncate font-mono text-[10px] mt-0.5">
                        {isHost ? room.mediaUrl : "•••••••••••••••••••••••••••• (Stream protected from public view)"}
                      </span>
                    </div>
                    <div className="bg-neutral-950 p-3.5 rounded-lg border border-white/5 space-y-1">
                      <span className="text-neutral-500 font-bold block uppercase text-[9px] tracking-wider">Security Access Limit</span>
                      <span className="text-orange-400 font-extrabold mt-1 block">
                        {room.password ? `Private (Key: ${room.password})` : "Public (Open Entry)"}
                      </span>
                    </div>
                  </div>

                  {/* Dynamic Password Management for Room Host */}
                  {isHost && (
                    <div className="bg-neutral-950 p-4 rounded-xl border border-white/5 space-y-3">
                      <h4 className="text-xs font-bold text-neutral-300 uppercase tracking-widest flex items-center gap-2">
                        <Settings className="w-3.5 h-3.5 text-orange-400" /> Host Settings: Password Key
                      </h4>
                      <p className="text-[10px] text-neutral-500">Add, remove, or modify the passcode on-the-fly. Empty value makes the room open to everyone.</p>
                      <div className="flex flex-col sm:flex-row items-center gap-2">
                        <input
                          type="text"
                          value={hostPasswordInput}
                          onChange={(e) => setHostPasswordInput(e.target.value)}
                          placeholder="Passcode password (leave empty to remove password)"
                          className="bg-neutral-900 border border-white/5 rounded-xl px-3 py-2 text-xs text-white placeholder:text-neutral-600 focus:outline-none focus:border-orange-500 w-full flex-1"
                        />
                        <button
                          onClick={() => {
                            socket.emit("update_room_password", { roomId: room.id, password: hostPasswordInput });
                            alert("Watch room passcode permissions updated successfully.");
                          }}
                          className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-white rounded-xl text-xs font-bold transition w-full sm:w-auto cursor-pointer"
                        >
                          Apply Password
                        </button>
                      </div>
                    </div>
                  )}

                  {/* MULTIPLE PLAYLIST STREAM SELECTION AND CHANGING */}
                  <div className="bg-neutral-950 p-4 rounded-xl border border-white/5 space-y-4">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold text-neutral-300 uppercase tracking-widest font-mono">
                        Party Streams Playlist ({room.playlist?.length || 0})
                      </h4>
                    </div>

                    {/* Host form to queue additional links */}
                    {isHost && (
                      <form 
                        onSubmit={(e) => {
                          e.preventDefault();
                          if (!addPlaylistItemUrl.trim() || !addPlaylistItemName.trim()) return;
                          socket.emit("add_room_playlist_item", {
                            roomId: room.id,
                            name: addPlaylistItemName.trim(),
                            url: addPlaylistItemUrl.trim()
                          });
                          setAddPlaylistItemName("");
                          setAddPlaylistItemUrl("");
                        }}
                        className="p-3 border border-white/5 rounded-xl space-y-2.5 bg-neutral-900/30"
                      >
                        <span className="text-[10px] font-bold text-orange-400 uppercase tracking-widest block">Add Multiple Stream Link or M3U Playlist URL</span>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          <input
                            type="text"
                            required
                            placeholder="Display Title Name"
                            value={addPlaylistItemName}
                            onChange={(e) => setAddPlaylistItemName(e.target.value)}
                            className="bg-neutral-900 border border-white/5 rounded-lg px-2 py-1.5 text-xs text-white focus:outline-none focus:border-orange-500"
                          />
                          <input
                            type="text"
                            required
                            placeholder="Direct URL address"
                            value={addPlaylistItemUrl}
                            onChange={(e) => setAddPlaylistItemUrl(e.target.value)}
                            className="bg-neutral-900 border border-white/5 rounded-lg px-2 py-1.5 text-xs text-white focus:outline-none focus:border-orange-500"
                          />
                        </div>
                        <button
                          type="submit"
                          className="w-full py-2 bg-gradient-to-r from-orange-500 to-red-600 hover:brightness-110 text-white font-extrabold text-xs rounded-lg shadow cursor-pointer transition"
                        >
                          Queue Playlist Item
                        </button>
                      </form>
                    )}

                    {/* Show listings */}
                    {(!room.playlist || room.playlist.length === 0) ? (
                      <p className="text-[10px] text-neutral-500 italic text-center py-2">No secondary playlist items defined. Feed working stream URL triggers above.</p>
                    ) : (
                      <div className="space-y-2 max-h-48 overflow-y-auto">
                        {room.playlist.map((item, idx) => {
                          const isActive = room.mediaUrl === item.url;
                          return (
                            <div 
                              key={idx}
                              className={`flex items-center justify-between p-2.5 rounded-xl border text-xs transition ${
                                isActive 
                                  ? "bg-orange-500/10 border-orange-500/25 text-orange-405" 
                                  : "bg-neutral-900 border-white/5 text-neutral-300"
                              }`}
                            >
                              <div className="truncate flex-1 pr-4">
                                <span className="font-extrabold text-neutral-200 block truncate">{item.name}</span>
                                <span className="text-[9px] text-neutral-500 truncate block font-mono">{item.url}</span>
                              </div>
                              <div className="flex gap-2 shrink-0">
                                {isHost ? (
                                  <>
                                    <button
                                      onClick={() => {
                                        socket.emit("change_room_stream", {
                                          roomId: room.id,
                                          name: item.name,
                                          url: item.url
                                        });
                                      }}
                                      className={`px-2.5 py-1 text-[10px] font-black rounded-md cursor-pointer ${
                                        isActive 
                                          ? "bg-orange-500 text-black brightness-110" 
                                          : "bg-neutral-800 hover:bg-neutral-700 text-white"
                                      }`}
                                    >
                                      {isActive ? "Viewing" : "Switch To"}
                                    </button>
                                    <button
                                      onClick={() => {
                                        socket.emit("remove_room_playlist_item", {
                                          roomId: room.id,
                                          index: idx
                                        });
                                      }}
                                      className="px-2 py-1 bg-red-500/10 hover:bg-red-500 hover:text-white text-red-500 text-[10px] font-extrabold rounded-md cursor-pointer transition"
                                    >
                                      Delete
                                    </button>
                                  </>
                                ) : (
                                  isActive && (
                                    <span className="text-[10px] font-extrabold text-orange-400 bg-orange-500/10 px-2 py-0.5 rounded-full uppercase tracking-widest">
                                      Active
                                    </span>
                                  )
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center justify-between text-xs text-neutral-500 uppercase tracking-widest font-black">
                    <span>Spectators Board</span>
                    {isHost && <span className="text-yellow-500">★ Room Administrator controls enabled</span>}
                  </div>
                  
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {room.users.map((u) => {
                      const isSelf = u.socketId === socket.id;
                      return (
                        <div 
                          key={u.socketId}
                          className="flex items-center justify-between bg-neutral-950 px-3 py-2 rounded-xl border border-white/5"
                        >
                          <div className="flex items-center gap-2">
                            {u.isHost ? (
                              <Crown className="w-4 h-4 text-yellow-500 fill-yellow-500 shrink-0" title="Host Crown" />
                            ) : (
                              <div className="w-2.5 h-2.5 bg-orange-550 rounded-full shrink-0"></div>
                            )}
                            <span className="text-sm font-semibold text-neutral-200">
                              @{u.username} {isSelf && <span className="text-[10px] text-neutral-500">(You)</span>}
                            </span>
                          </div>

                          {/* Moderation panel (Only Host can view and trigger) */}
                          {isHost && !u.isHost && (
                            <div className="flex gap-2">
                              <button
                                onClick={() => handleKickUser(u.socketId)}
                                className="px-2.5 py-1 bg-yellow-500/10 hover:bg-yellow-500 text-yellow-500 hover:text-neutral-950 font-bold text-[10px] rounded"
                              >
                                Kick
                              </button>
                              <button
                                onClick={() => {
                                  if (confirm(`Ban and Blacklist candidate @${u.username}?`)) {
                                    handleBlockUserByUsername(u.username);
                                  }
                                }}
                                className="px-2.5 py-1 bg-red-500/10 hover:bg-red-500 text-red-500 hover:text-neutral-950 font-bold text-[10px] rounded"
                              >
                                Ban user
                              </button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>

        </div>

        {/* Right pane: Dedicated Room Chat */}
        <div className="lg:col-span-1 h-full flex flex-col overflow-hidden min-h-[400px]">
          <StreamChat 
            roomId={room.id} 
            onModeratorAction={{
              isHost,
              kickUser: handleKickUser,
              blockUser: handleBlockUserByUsername,
              roomUsers: room.users
            }}
          />
        </div>

      </div>
    </div>
  );
}
