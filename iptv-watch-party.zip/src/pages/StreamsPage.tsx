import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { socket } from "../lib/socket";
import { StreamItem } from "../types";
import { 
  Play, Radio, Users, Plus, Search, Layers, ShieldAlert, Laptop
} from "lucide-react";

export default function StreamsPage() {
  const navigate = useNavigate();
  const [streams, setStreams] = useState<StreamItem[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [visibleCount, setVisibleCount] = useState(12);

  // Reset pagination on search query or category changes
  useEffect(() => {
    setVisibleCount(12);
  }, [searchQuery, selectedCategory]);

  useEffect(() => {
    // Initial load
    fetch("/api/streams")
      .then(res => res.json())
      .then(data => setStreams(data))
      .catch(() => {});

    // Listen to real-world updates from administrative portal or background stream checks
    const handleStreamsList = (list: StreamItem[]) => {
      setStreams(list);
    };

    const handleStreamStatusUpdate = (update: { id: string; status: "online" | "offline" }) => {
      setStreams(prev => prev.map(s => {
        if (s.id === update.id) {
          return { ...s, status: update.status };
        }
        return s;
      }));
    };

    socket.on("streams_list", handleStreamsList);
    socket.on("stream_status", handleStreamStatusUpdate);

    return () => {
      socket.off("streams_list", handleStreamsList);
      socket.off("stream_status", handleStreamStatusUpdate);
    };
  }, []);

  // Compute Categories from streams list
  const categories = ["All", ...Array.from(new Set(streams.map(s => s.category || "Uncategorized")))];

  // Match filtering criteria
  const filteredStreams = streams.filter(stream => {
    const matchesSearch = stream.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          (stream.category || "").toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "All" || stream.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const paginatedStreams = filteredStreams.slice(0, visibleCount);

  const featured = streams.find(s => s.featured) || streams[0];

  const handleLaunchParty = (stream: StreamItem) => {
    navigate(`/create-room?url=${encodeURIComponent(stream.url)}&name=${encodeURIComponent(stream.name)}`);
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans selection:bg-orange-500 selection:text-white pb-12">
      
      {/* Dynamic Header */}
      <header id="iptv_streams_navbar" className="px-8 border-b border-white/10 flex flex-col md:flex-row items-center justify-between bg-black/40 backdrop-blur-md sticky top-0 z-50 py-4 md:py-0 md:h-16 gap-4">
        <div className="flex items-center gap-8">
          <div className="text-2xl font-black tracking-tighter bg-gradient-to-r from-orange-500 to-red-600 bg-clip-text text-transparent">
            VORTEX.TV
          </div>
          <nav className="flex gap-6 text-sm font-medium text-white/60">
            <Link to="/streams" className="text-white border-b-2 border-orange-500 pb-4 pt-4 shrink-0">STREAMS</Link>
            <Link to="/public-rooms" className="hover:text-white transition-colors shrink-0">WATCH LOBBY</Link>
            <Link to="/create-room" className="hover:text-white transition-colors shrink-0">CREATE THEATER</Link>
          </nav>
        </div>

        {/* Navigator Links */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-1.5 bg-white/5 rounded-full border border-white/10 text-xs text-orange-400">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-orange-500"></span>
            </span>
            42 LIVE NOW
          </div>
        </div>
      </header>

      {/* Hero Display Featured Section */}
      {featured && (
        <div className="max-w-7xl mx-auto w-full px-6 pt-6">
          <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-neutral-900 to-neutral-950 border border-white/10 shadow-2xl min-h-[300px] flex flex-col md:flex-row items-center p-6 md:p-10 gap-8">
            <div className="absolute inset-x-0 bottom-0 top-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-orange-500/10 via-transparent to-transparent pointer-events-none"></div>
            
            {/* Poster / Logo */}
            <div className="w-full md:w-80 aspect-video md:aspect-[4/3] rounded-2xl overflow-hidden border border-white/5 bg-neutral-900 shrink-0 shadow-xl relative group">
              <img 
                src={featured.logo || "https://images.unsplash.com/photo-1542204172-e7052809a936?w=400&fit=crop&q=80"} 
                alt={featured.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
              />
              <div className="absolute inset-0 bg-neutral-950/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition duration-300">
                <span className="p-3 bg-orange-500 text-black rounded-full shadow-lg">
                  <Play className="w-6 h-6 fill-black" />
                </span>
              </div>
            </div>

            {/* Meta details */}
            <div className="flex-1 flex flex-col justify-center items-start gap-3 relative z-10">
              <span className="px-3 py-1 bg-orange-500/10 text-orange-400 border border-orange-500/20 rounded-full text-xs font-bold uppercase tracking-wide">
                ⭐ Featured Channels
              </span>
              <h2 className="text-2xl md:text-4xl font-extrabold text-white tracking-tight leading-tight">{featured.name}</h2>
              <p className="text-neutral-400 text-sm max-w-lg mb-2 leading-relaxed">
                Join a dynamic crowd, stream this public presentation natively with instant independent viewing, or generate a synchronized control terminal for multi-user chat.
              </p>
              
              <div className="flex flex-wrap gap-2.5">
                <Link
                  to={`/watch?url=${encodeURIComponent(featured.url)}&id=${featured.id}&name=${encodeURIComponent(featured.name)}&logo=${encodeURIComponent(featured.logo || "")}`}
                  className="flex items-center gap-2 px-5 py-3 bg-gradient-to-r from-orange-500 to-red-600 hover:brightness-110 font-bold text-white rounded-xl transition shadow-lg text-sm"
                >
                  <Play className="w-4 h-4 fill-white text-white" />
                  Watch Directly
                </Link>
                <button
                  onClick={() => handleLaunchParty(featured)}
                  className="flex items-center gap-2 px-5 py-3 bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-200 font-bold rounded-xl transition text-sm"
                >
                  <Users className="w-4 h-4 text-orange-400" />
                  Launch Watch Party
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Stream Directory */}
      <main className="max-w-7xl mx-auto w-full px-6 mt-10 grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* Sidebar filters */}
        <div className="lg:col-span-1 flex flex-col gap-6">
          {/* Quick Room Code Join */}
          <div className="bg-neutral-900 border border-white/5 rounded-2xl p-4 flex flex-col gap-3">
            <h4 className="text-xs font-extrabold uppercase tracking-widest text-neutral-400 flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5 text-orange-400" />
              Quick Join Room
            </h4>
            <form 
              onSubmit={(e) => {
                e.preventDefault();
                const code = (e.currentTarget.elements.namedItem("roomCode") as HTMLInputElement).value.trim().toUpperCase();
                if (code) {
                  navigate(`/room/${code}`);
                }
              }}
              className="flex items-center gap-1.5"
            >
              <input
                name="roomCode"
                type="text"
                required
                maxLength={6}
                placeholder="A7B9K2"
                className="bg-neutral-950 border border-white/5 rounded-lg px-2.5 py-2 text-xs text-center text-white focus:outline-none focus:border-orange-500 font-mono tracking-widest uppercase w-full"
              />
              <button
                type="submit"
                className="py-2 px-3 bg-gradient-to-r from-orange-500 to-red-600 hover:brightness-110 text-white font-extrabold rounded-lg text-xs leading-none shrink-0"
              >
                Join
              </button>
            </form>
          </div>

          {/* Quick Search */}
          <div className="relative">
            <Search className="absolute left-3.5 top-3.5 w-4 h-4 text-neutral-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search stream name..."
              className="w-full bg-neutral-900 border border-white/5 rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-orange-500/50 focus:ring-1 focus:ring-orange-500/50 transition"
            />
          </div>

          {/* Categories Pill Container */}
          <div className="bg-neutral-900/40 border border-white/5 rounded-2xl p-4 flex flex-col gap-2.5 overflow-hidden">
            <h4 className="text-xs font-extrabold uppercase tracking-widest text-neutral-500 flex items-center gap-1.5 px-2">
              <Layers className="w-3.5 h-3.5" />
              Categories
            </h4>
            <div className="flex flex-row lg:flex-col overflow-x-auto lg:overflow-visible flex-nowrap lg:flex-wrap gap-1.5 pb-2 lg:pb-0 scrollbar-none">
              {categories.map((cat) => {
                const count = cat === "All" ? streams.length : streams.filter(s => s.category === cat).length;
                return (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`shrink-0 lg:shrink text-left px-3 py-2 rounded-lg text-xs font-bold transition flex items-center justify-between gap-3 ${
                      selectedCategory === cat 
                        ? "bg-orange-500 text-black font-black shadow-md" 
                        : "text-neutral-400 hover:text-white hover:bg-neutral-900"
                    }`}
                  >
                    <span className="truncate">{cat}</span>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded-md ${selectedCategory === cat ? "bg-black/20 text-black" : "bg-neutral-800 text-neutral-500"}`}>
                      {count}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Streams Grid content */}
        <div className="lg:col-span-3 flex flex-col gap-6">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <h3 className="text-xl font-bold tracking-tight text-white">Stream Collection ({filteredStreams.length})</h3>
              <p className="text-xs text-neutral-500">Live IPTV streams currently cached locally</p>
            </div>
          </div>          {filteredStreams.length === 0 ? (
            <div className="py-20 bg-neutral-900/10 border border-white/5 rounded-2xl flex flex-col items-center justify-center p-6 text-center gap-4">
              <Laptop className="w-12 h-12 text-neutral-600 animate-bounce" />
              <div>
                <h4 className="font-bold text-neutral-300">No channels found</h4>
                <p className="text-xs text-neutral-500 max-w-xs mt-1">
                  Adjust your categories or head back to the admin portal to synchronize a Stalker or M3U index.
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div id="iptv_streams_grid" className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
                {paginatedStreams.map((stream) => (
                  <div 
                    key={stream.id}
                    id={`stream_card_${stream.id}`}
                    className="bg-neutral-900 border border-white/5 rounded-2xl overflow-hidden hover:border-white/10 hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
                  >
                    <div className="p-4 flex flex-col gap-3">
                      {/* Cover Photo */}
                      <div className="w-full aspect-video rounded-xl bg-neutral-950 border border-white/5 overflow-hidden relative group">
                        <img 
                          src={stream.logo || "https://images.unsplash.com/photo-1542204172-e7052809a936?w=200&fit=crop&q=80"} 
                          alt={stream.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover group-hover:scale-105 transition"
                        />
                        <span className={`absolute top-2.5 right-2.5 px-2.5 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider shadow-md flex items-center gap-1 ${
                          stream.status === "online" 
                            ? "bg-red-600 text-white animate-pulse" 
                            : "bg-neutral-800 text-neutral-400"
                        }`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${stream.status === "online" ? "bg-white" : "bg-neutral-500"}`}></span>
                          {stream.status}
                        </span>
                      </div>

                      {/* Metadata details */}
                      <div>
                        <span className="text-[10px] bg-neutral-800 text-neutral-400 px-2 py-0.5 rounded font-bold uppercase">
                          {stream.category || "Uncategorized"}
                        </span>
                        <h4 className="font-extrabold text-neutral-100 text-base tracking-tight mt-1 truncate hover:text-orange-400 transition" title={stream.name}>
                          {stream.name}
                        </h4>
                        <p className="text-[10px] text-neutral-600 truncate mt-0.5">High Stability Live Feed</p>
                      </div>
                    </div>

                    {/* Actions Drawer */}
                    <div className="px-4 py-3 bg-neutral-950 border-t border-white/5 flex items-center justify-between gap-2">
                      <Link
                        to={`/watch?url=${encodeURIComponent(stream.url)}&id=${stream.id}&name=${encodeURIComponent(stream.name)}&logo=${encodeURIComponent(stream.logo || "")}`}
                        className="flex-1 py-1.5 px-3 bg-gradient-to-r from-orange-500 to-red-600 hover:brightness-110 text-white font-bold rounded-lg text-xs text-center transition flex items-center justify-center gap-1 shadow"
                      >
                        <Play className="w-3.5 h-3.5 fill-white text-white" />
                        Watch Direct
                      </Link>
                      <button
                        onClick={() => handleLaunchParty(stream)}
                        className="flex-1 py-1.5 px-3 bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-300 font-bold rounded-lg text-xs transition flex items-center justify-center gap-1"
                      >
                        <Users className="w-3.5 h-3.5 text-orange-400" />
                        Party Room
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {filteredStreams.length > visibleCount && (
                <div className="flex justify-center pt-4">
                  <button
                    onClick={() => setVisibleCount(prev => prev + 12)}
                    className="px-6 py-3.5 bg-neutral-900 hover:bg-neutral-800 text-orange-400 hover:text-white font-extrabold border border-white/5 rounded-2xl transition shadow-lg text-xs uppercase tracking-wider cursor-pointer"
                  >
                    Load More Channels (+12)
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
