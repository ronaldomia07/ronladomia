import { HashRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import StreamsPage from "./pages/StreamsPage";
import WatchPage from "./pages/WatchPage";
import CreateRoomPage from "./pages/CreateRoomPage";
import RoomPage from "./pages/RoomPage";
import PublicRoomsPage from "./pages/PublicRoomsPage";
import AdminPage from "./pages/AdminPage";

export default function App() {
  return (
    <Router>
      <Routes>
        {/* Streams directory dashboard is the root gateway */}
        <Route path="/" element={<Navigate to="/streams" replace />} />
        <Route path="/streams" element={<StreamsPage />} />
        
        {/* Direct watch is the independent playback screen */}
        <Route path="/watch" element={<WatchPage />} />
        
        {/* Creation panel */}
        <Route path="/create-room" element={<CreateRoomPage />} />
        
        {/* Active synchronizing Watch rooms */}
        <Route path="/room/:id" element={<RoomPage />} />
        
        {/* Active watch party listings */}
        <Route path="/public-rooms" element={<PublicRoomsPage />} />
        
        {/* Administrative terminal */}
        <Route path="/admin" element={<AdminPage />} />
        
        {/* Catch-all fallback redirection */}
        <Route path="*" element={<Navigate to="/streams" replace />} />
      </Routes>
    </Router>
  );
}

