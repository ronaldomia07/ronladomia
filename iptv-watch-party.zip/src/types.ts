export interface StreamItem {
  id: string;
  name: string;
  url: string;
  logo?: string;
  category?: string;
  sourceType: "direct" | "m3u" | "xtream" | "stalker";
  featured: boolean;
  status: "online" | "offline";
  createdAt: number;
}

export interface User {
  socketId: string;
  username: string;
  isHost: boolean;
}

export interface PlaylistItem {
  name: string;
  url: string;
  logo?: string;
}

export interface Message {
  id: string;
  username: string;
  content: string;
  type: "text" | "voice" | "sticker";
  timestamp: number;
  replyTo?: string;
  reactions: Record<string, string[]>; // emoji -> array of usernames
  expiresAt: number;
}

export interface Room {
  id: string;
  name: string;
  hostId: string; // socketId of the host
  mediaUrl: string;
  mediaName?: string;
  currentTime: number;
  isPlaying: boolean;
  public: boolean;
  password?: string;
  syncEnabled: boolean;
  blockedUsers: string[]; // usernames that are blocked
  users: User[];
  messages: Message[];
  playlist?: PlaylistItem[];
  createdAt: number;
  lastActivity: number;
}
