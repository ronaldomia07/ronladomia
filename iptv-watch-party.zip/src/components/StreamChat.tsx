import React, { useEffect, useState, useRef } from "react";
import { socket } from "../lib/socket";
import { Message, User } from "../types";
import { 
  Send, Smile, Mic, X, MessageSquare, AlertCircle, 
  Trash2, ShieldAlert, Reply, Volume2, Music 
} from "lucide-react";

interface StreamChatProps {
  roomId: string; // Either "chat:stream:{streamId}" or "room_{roomId}"
  onModeratorAction?: {
    isHost: boolean;
    kickUser: (socketId: string) => void;
    blockUser: (username: string) => void;
    roomUsers: User[];
  };
}

const STICKER_PRESETS = [
  "🍿 Popcorn", "🥳 Let's Go!", "😮 Wow!", "😂 LoL!", "🔥 Hype!",
  "🍕 Pizza", "🥤 Soda", "👏 Bravo", "😱 Suspense", "✨ Magic"
];

export default function StreamChat({ roomId, onModeratorAction }: StreamChatProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState("");
  const [username, setUsername] = useState<string>(() => {
    return localStorage.getItem("iptv_username") || "";
  });
  const [usernameInput, setUsernameInput] = useState("");
  const [showUsernamePrompt, setShowUsernamePrompt] = useState(false);
  const [replyTo, setReplyTo] = useState<Message | null>(null);
  const [showStickers, setShowStickers] = useState(false);
  
  // Voice Recording state
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordingTimerRef = useRef<any>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const chatBottomRef = useRef<HTMLDivElement | null>(null);

  // Chat Slow-mode 5s cooldown state
  const [cooldownTime, setCooldownTime] = useState(0);

  useEffect(() => {
    if (cooldownTime <= 0) return;
    const interval = setInterval(() => {
      setCooldownTime(prev => prev - 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [cooldownTime]);

  const startSlowCooldown = () => {
    setCooldownTime(5);
  };

  // Sync state and socket binders
  useEffect(() => {
    // If it's a direct stream chat, trigger historical handshake
    if (roomId.startsWith("chat:stream:")) {
      socket.emit("join_direct_chat", { streamId: roomId.replace("chat:stream:", "") });
    }

    const handleChatMessage = (msg: Message) => {
      setMessages(prev => {
        // Prevent duplicate loads
        if (prev.some(m => m.id === msg.id)) return prev;
        return [...prev, msg];
      });
      scrollToBottom();
    };

    const handleHistory = (data: { streamId: string; messages: Message[] }) => {
      setMessages(data.messages);
      scrollToBottom();
    };

    const handleReactionUpdate = (data: { messageId: string; reactions: Record<string, string[]> }) => {
      setMessages(prev => prev.map(m => {
        if (m.id === data.messageId) {
          return { ...m, reactions: data.reactions };
        }
        return m;
      }));
    };

    const handleCleared = (data: { messages: Message[] }) => {
      setMessages(data.messages);
    };

    socket.on("chat_message", handleChatMessage);
    socket.on("direct_chat_history", handleHistory);
    socket.on("message_reaction_update", handleReactionUpdate);
    socket.on("chat_messages_cleared", handleCleared);

    return () => {
      socket.off("chat_message", handleChatMessage);
      socket.off("direct_chat_history", handleHistory);
      socket.off("message_reaction_update", handleReactionUpdate);
      socket.off("chat_messages_cleared", handleCleared);
    };
  }, [roomId]);

  // Push local username into sockets
  useEffect(() => {
    if (username) {
      socket.emit("set_username", { username });
      localStorage.setItem("iptv_username", username);
    }
  }, [username]);

  const scrollToBottom = () => {
    setTimeout(() => {
      chatBottomRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 100);
  };

  const handleSendText = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim()) return;

    if (cooldownTime > 0) {
      alert(`Slow mode is active. Please wait ${cooldownTime} second(s) before sending.`);
      return;
    }

    if (!username) {
      // Prompt nickname onboarding inline
      setShowUsernamePrompt(true);
      return;
    }

    const payload = {
      roomId,
      content: inputText.trim(),
      type: "text",
      replyTo: replyTo?.id,
      username
    };

    socket.emit("chat_message", payload);
    setInputText("");
    setReplyTo(null);
    startSlowCooldown();
  };

  const handleSendSticker = (sticker: string) => {
    if (cooldownTime > 0) {
      alert(`Slow mode is active. Please wait ${cooldownTime} second(s) before sending.`);
      return;
    }

    if (!username) {
      setShowUsernamePrompt(true);
      return;
    }
    
    socket.emit("chat_message", {
      roomId,
      content: sticker,
      type: "sticker",
      username
    });
    setShowStickers(false);
    startSlowCooldown();
  };

  // ------------------------------------------------------------
  // Voice recording routines (MediaRecorder API)
  // ------------------------------------------------------------
  const startRecording = async () => {
    if (!username) {
      setShowUsernamePrompt(true);
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunksRef.current = [];
      const options = { mimeType: "audio/webm" };
      let recorder: MediaRecorder;
      try {
        recorder = new MediaRecorder(stream, options);
      } catch {
        recorder = new MediaRecorder(stream);
      }

      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      recorder.onstop = () => {
        if (cooldownTime > 0) {
          alert(`Slow mode is active. Please wait ${cooldownTime} second(s) before sending.`);
          return;
        }

        const audioBlob = new Blob(audioChunksRef.current, { type: "audio/webm" });
        // Convert to Base64 to transmit via Socket
        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = () => {
          const base64Audio = reader.result as string;
          socket.emit("voice_message", {
            roomId,
            audioBlobBase64: base64Audio,
            username
          });
        };
        // Disable tracks to avoid lingering system activity indicators
        stream.getTracks().forEach(track => track.stop());
        startSlowCooldown();
      };

      recorder.start(200);
      setIsRecording(true);
      setRecordingSeconds(0);

      recordingTimerRef.current = setInterval(() => {
        setRecordingSeconds(prev => {
          if (prev >= 29) {
            // Force stop at 30 seconds maximum
            stopRecording();
            return 30;
          }
          return prev + 1;
        });
      }, 1000);

    } catch (err) {
      alert("Microphone permission denied or unsupported device.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
    }
    if (recordingTimerRef.current) {
      clearInterval(recordingTimerRef.current);
    }
    setIsRecording(false);
  };

  const cancelRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      // Drop audio chunks so they are not transmitted
      audioChunksRef.current = [];
    }
    if (recordingTimerRef.current) {
      clearInterval(recordingTimerRef.current);
    }
    setIsRecording(false);
  };

  // Emojis for Reactions
  const handleToggleReaction = (messageId: string, emoji: string) => {
    if (!username) {
      setShowUsernamePrompt(true);
      return;
    }
    socket.emit("message_reaction", {
      roomId,
      messageId,
      reaction: emoji,
      username
    });
  };

  const handleSetUsernameSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = usernameInput.trim();
    if (clean) {
      setUsername(clean);
      setShowUsernamePrompt(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-neutral-900 border border-neutral-800 rounded-xl overflow-hidden shadow-lg select-none">
      
      {/* Header */}
      <div className="px-4 py-3 bg-neutral-800/60 border-b border-white/5 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MessageSquare className="w-4 h-4 text-orange-400" />
          <h3 className="text-white text-sm font-semibold">Live Room Chat</h3>
        </div>
        <div className="flex items-center gap-2 text-xs">
          <span className="w-2 h-2 rounded-full bg-orange-500 animate-pulse"></span>
          <span className="text-neutral-400">Feed (3m TTL)</span>
        </div>
      </div>

      {/* Message Stream */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 min-h-[300px]">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 text-neutral-500 gap-2">
            <Smile className="w-10 h-10 text-neutral-600 animate-bounce" />
            <p className="text-xs">No active messages. Be the first to start the hype!</p>
          </div>
        ) : (
          messages.map((msg) => {
            const hasReactions = msg.reactions && Object.keys(msg.reactions).length > 0;
            const parentMsg = msg.replyTo ? messages.find(m => m.id === msg.replyTo) : null;

            return (
              <div key={msg.id} className="group relative flex flex-col items-start gap-1 p-2 rounded-lg hover:bg-neutral-800/40 transition">
                
                {/* Reply display header */}
                {parentMsg && (
                  <div className="flex items-center gap-1 text-[11px] text-neutral-500 mt-0.5 ml-2">
                    <Reply className="w-3 h-3 rotate-180" />
                    <span>replied to <strong className="text-neutral-400">@{parentMsg.username}</strong></span>
                    <span className="truncate max-w-[120px] bg-neutral-800 px-1 py-0.5 rounded italic">
                      "{parentMsg.type === "voice" ? "Voice Note" : parentMsg.content}"
                    </span>
                  </div>
                )}

                {/* Message Meta Info */}
                <div className="flex items-baseline gap-2">
                  <span className="text-sm font-bold text-orange-400">@{msg.username}</span>
                  <span className="text-[10px] text-neutral-500">
                    {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>

                {/* Body Content */}
                <div className="text-sm text-neutral-200 break-words w-full">
                  {msg.type === "text" && (
                    <p className="whitespace-pre-wrap">{msg.content}</p>
                  )}

                  {msg.type === "sticker" && (
                    <span className="inline-block text-2xl p-1 bg-neutral-800/80 rounded-lg shadow-sm border border-neutral-700/50">
                      {msg.content}
                    </span>
                  )}

                  {msg.type === "voice" && (
                    <div className="mt-1 inline-flex items-center gap-3 bg-neutral-800 hover:bg-neutral-700/80 px-3 py-2 rounded-xl border border-white/5 max-w-xs transition">
                      <button 
                        onClick={() => {
                          const sound = new Audio(msg.content);
                          sound.play().catch(() => {});
                        }}
                        className="p-1.5 bg-orange-500 text-black rounded-full hover:bg-orange-400 transition shadow-inner"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                      </button>
                      <div className="flex flex-col gap-0.5">
                        <span className="text-xs font-semibold text-neutral-200">Play Voice Note</span>
                        <div className="flex items-center gap-1.5">
                          <Music className="w-3 h-3 text-neutral-400 animate-pulse" />
                          <span className="text-[10px] text-neutral-500 font-mono">Audio Stream</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Display reactions */}
                {hasReactions && (
                  <div className="flex flex-wrap gap-1 mt-1.5">
                    {Object.entries(msg.reactions).map(([reactionEmoji, usernames]) => {
                      const userNamesList = usernames as string[];
                      const userReacted = userNamesList.includes(username);
                      return (
                        <button
                          key={reactionEmoji}
                          onClick={() => handleToggleReaction(msg.id, reactionEmoji)}
                          className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-xs border transition ${
                            userReacted 
                              ? "bg-orange-500/10 border-orange-500 text-orange-300" 
                              : "bg-neutral-800 border-neutral-700 text-neutral-400 hover:border-neutral-600"
                          }`}
                          title={userNamesList.join(", ")}
                        >
                          <span>{reactionEmoji}</span>
                          <span className="text-[10px]">{userNamesList.length}</span>
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* Hover Quick Actions Bar */}
                <div className="absolute right-2 top-2 opacity-0 group-hover:opacity-100 flex items-center bg-neutral-800 border border-neutral-700 rounded-lg shadow-md transition-all duration-200 overflow-hidden divide-x divide-neutral-700 z-10">
                  {/* Reaction buttons */}
                  <div className="flex items-center px-1">
                    {["❤️", "😂", "😮", "🔥"].map(emoji => (
                      <button
                        key={emoji}
                        onClick={() => handleToggleReaction(msg.id, emoji)}
                        className="p-1 text-sm hover:scale-125 transition"
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>

                  {/* Reply Button */}
                  <button
                    onClick={() => setReplyTo(msg)}
                    className="p-1 px-2 text-[11px] text-neutral-300 hover:text-white flex items-center gap-1 hover:bg-neutral-700 transition"
                  >
                    <Reply className="w-3 h-3" />
                    Reply
                  </button>

                  {/* Moderator admin Controls */}
                  {onModeratorAction?.isHost && (
                    <div className="flex items-center divide-x divide-neutral-700">
                      {/* We look up socket ID for moderator actions */}
                      {(() => {
                        const messageUser = onModeratorAction.roomUsers.find(u => u.username === msg.username);
                        if (!messageUser || messageUser.isHost) return null;
                        return (
                          <>
                            <button
                              onClick={() => onModeratorAction.kickUser(messageUser.socketId)}
                              className="p-1 px-2 text-[10px] text-yellow-500 hover:text-yellow-400 hover:bg-yellow-950/20 transition"
                              title="Kick user"
                            >
                              Kick
                            </button>
                            <button
                              onClick={() => {
                                if (confirm(`Are you sure you want to ban @${msg.username} from this room?`)) {
                                  onModeratorAction.blockUser(msg.username);
                                }
                              }}
                              className="p-1 px-2 text-[10px] text-red-500 hover:text-red-400 hover:bg-red-950/20 transition flex items-center gap-0.5"
                              title="Ban and Block username"
                            >
                              <ShieldAlert className="w-3 h-3" />
                              Ban
                            </button>
                          </>
                        );
                      })()}
                    </div>
                  )}
                </div>

              </div>
            );
          })
        )}
        <div ref={chatBottomRef}></div>
      </div>

      {/* Stickers Panel */}
      {showStickers && (
        <div className="px-3 py-2 bg-neutral-800 border-t border-neutral-800">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] text-neutral-400 font-semibold uppercase tracking-wide">Quick Stickers</span>
            <button onClick={() => setShowStickers(false)} className="text-neutral-500 hover:text-white">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="grid grid-cols-5 gap-1.5 max-h-24 overflow-y-auto">
            {STICKER_PRESETS.map(sticker => (
              <button
                key={sticker}
                onClick={() => handleSendSticker(sticker)}
                className="py-1 text-xs bg-neutral-900 border border-neutral-700 rounded-lg hover:bg-neutral-700 text-neutral-200 transition"
              >
                {sticker}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Reply Lock indicator */}
      {replyTo && (
        <div className="px-3 py-1.5 bg-neutral-800/80 border-t border-white/5 flex items-center justify-between text-xs text-neutral-400">
          <div className="flex items-center gap-1.5">
            <Reply className="w-3.5 h-3.5 text-orange-400" />
            <span>Replying to <strong className="text-orange-350">@{replyTo.username}</strong></span>
          </div>
          <button 
            onClick={() => setReplyTo(null)}
            className="text-neutral-500 hover:text-white transition"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Recording Lock indicator */}
      {isRecording && (
        <div className="px-4 py-3 bg-red-950/40 border-t border-red-900/40 flex items-center justify-between text-xs text-red-400">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-ping"></span>
            <span className="font-semibold">Recording Voice Clip: {recordingSeconds}s / 30s limit</span>
          </div>
          <div className="flex items-center gap-3">
            <button 
              onClick={cancelRecording}
              className="text-neutral-400 hover:text-white transition uppercase font-bold tracking-wider text-[10px]"
            >
              Cancel
            </button>
            <button 
              onClick={stopRecording}
              className="px-2.5 py-1 bg-red-600 hover:bg-red-500 text-white rounded font-bold uppercase tracking-wider text-[10px]"
            >
              Send Note
            </button>
          </div>
        </div>
      )}

      {/* Input Action Form Footer */}
      {!isRecording && (
        <form onSubmit={handleSendText} className="p-3 bg-neutral-950 border-t border-white/5 flex items-center gap-2">
          
          {/* Stickers shortcut toggler */}
          <button
            type="button"
            disabled={cooldownTime > 0}
            onClick={() => setShowStickers(!showStickers)}
            className={`p-2 rounded-lg transition disabled:opacity-40 ${showStickers ? "bg-orange-500 text-black" : "text-neutral-400 hover:text-white hover:bg-neutral-800"}`}
            title={cooldownTime > 0 ? "Slow-mode active" : "Stickers"}
          >
            <Smile className="w-5 h-5" />
          </button>

          {/* Voice recorder action */}
          <button
            type="button"
            disabled={cooldownTime > 0}
            onClick={startRecording}
            className="p-2 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-lg transition disabled:opacity-40"
            title={cooldownTime > 0 ? "Slow-mode active" : "Record voice note (30s max)"}
          >
            <Mic className="w-5 h-5" />
          </button>

          {/* Text entry field */}
          <input
            type="text"
            value={inputText}
            disabled={cooldownTime > 0}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={cooldownTime > 0 ? `Slow-mode active (wait ${cooldownTime}s)...` : "Type message..."}
            className="flex-1 bg-neutral-900 border border-white/5 rounded-lg px-3 py-2 text-sm text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-orange-500/50 disabled:opacity-50 disabled:cursor-not-allowed"
          />

          <button
            type="submit"
            disabled={cooldownTime > 0 || !inputText.trim()}
            className="p-2 bg-orange-500 text-black rounded-lg hover:bg-orange-400 transition disabled:bg-neutral-800 disabled:text-neutral-600 disabled:cursor-not-allowed"
          >
            {cooldownTime > 0 ? (
              <span className="text-[10px] font-black">{cooldownTime}s</span>
            ) : (
              <Send className="w-4 h-4" />
            )}
          </button>
        </form>
      )}

      {/* Nickname validation Overlay popover */}
      {showUsernamePrompt && (
        <div className="absolute inset-0 z-50 bg-black/90 flex flex-col items-center justify-center p-6 text-center select-text">
          <div className="w-full max-w-sm bg-neutral-900 border border-white/5 rounded-xl p-5 shadow-2xl flex flex-col gap-4">
            <div className="flex flex-col items-center gap-1.5">
              <AlertCircle className="w-10 h-10 text-orange-400 animate-bounce" />
              <h4 className="text-white font-bold text-base">Onboarding Identity</h4>
              <p className="text-xs text-neutral-400">Choose a fast nickname to chat and participate in real-time parties.</p>
            </div>
            
            <form onSubmit={handleSetUsernameSubmit} className="flex flex-col gap-3">
              <input
                type="text"
                required
                maxLength={20}
                value={usernameInput}
                onChange={(e) => setUsernameInput(e.target.value.replace(/[^a-zA-Z0-9_]/g, ""))}
                placeholder="Nickname (letters, numbers, _)"
                className="w-full bg-neutral-950 border border-white/5 rounded-lg px-4 py-2.5 text-sm text-center text-white focus:outline-none focus:border-orange-500/50"
              />
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowUsernamePrompt(false)}
                  className="flex-1 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-semibold rounded-lg text-xs transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-orange-500 hover:bg-orange-400 text-black font-bold rounded-lg text-xs transition uppercase tracking-wide"
                >
                  Join Chat
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
