import React, { useEffect, useRef, useState } from "react";
import Hls from "hls.js";
import { Play, Pause, Volume2, VolumeX, Maximize, RotateCcw, AlertTriangle, Radio } from "lucide-react";

interface StreamPlayerProps {
  url: string;
  isPlaying?: boolean;
  currentTime?: number;
  isHost?: boolean;
  syncEnabled?: boolean;
  onPlay?: (time: number) => void;
  onPause?: (time: number) => void;
  onSeek?: (time: number) => void;
  onTimeUpdate?: (time: number) => void;
}

export default function StreamPlayer({
  url,
  isPlaying = false,
  currentTime = 0,
  isHost = false,
  syncEnabled = true,
  onPlay,
  onPause,
  onSeek,
  onTimeUpdate
}: StreamPlayerProps) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const hlsRef = useRef<Hls | null>(null);
  const [localIsPlaying, setLocalIsPlaying] = useState(false);
  const [volume, setVolume] = useState(0.8);
  const [isMuted, setIsMuted] = useState(false);
  const [duration, setDuration] = useState(0);
  const [progress, setProgress] = useState(0);
  const [videoStatus, setVideoStatus] = useState<"loading" | "ready" | "error">("loading");
  const [errorMessage, setErrorMessage] = useState("");
  const [qualities, setQualities] = useState<{ index: number; label: string }[]>([]);
  const [currentQuality, setCurrentQuality] = useState<number>(-1);
  const isSyncingFromProp = useRef(false);

  // Playback control guard wrapper to avoid triggering infinite cycle callbacks
  const runWithoutSyncCycle = (fn: () => void) => {
    isSyncingFromProp.current = true;
    fn();
    setTimeout(() => {
      isSyncingFromProp.current = false;
    }, 150);
  };

  // Initialize stream (HLS or native MP4)
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !url) return;

    setVideoStatus("loading");
    setErrorMessage("");
    setQualities([]);
    setCurrentQuality(-1);

    // Cleanup previous Hls instance
    if (hlsRef.current) {
      hlsRef.current.destroy();
      hlsRef.current = null;
    }

    const isHls = url.includes(".m3u8") || url.toLowerCase().includes("m3u8");

    if (isHls) {
      if (Hls.isSupported()) {
        const hls = new Hls({
          maxMaxBufferLength: 10,
          enableWorker: true
        });
        hlsRef.current = hls;
        hls.loadSource(url);
        hls.attachMedia(video);
        
        hls.on(Hls.Events.MANIFEST_PARSED, () => {
          setVideoStatus("ready");
          if (hls.levels && hls.levels.length > 0) {
            const list = hls.levels.map((lvl, index) => {
              const label = lvl.height 
                ? `${lvl.height}p` 
                : lvl.bitrate 
                  ? `${Math.round(lvl.bitrate / 1000)}k` 
                  : `Level ${index + 1}`;
              return { index, label };
            });
            setQualities([{ index: -1, label: "Auto" }, ...list]);
          } else {
            setQualities([]);
          }
          if (isPlaying) {
            video.play().catch(() => {});
          }
        });

        hls.on(Hls.Events.ERROR, (_event, data) => {
          if (data.fatal) {
            switch (data.type) {
              case Hls.ErrorTypes.NETWORK_ERROR:
                hls.startLoad();
                break;
              case Hls.ErrorTypes.MEDIA_ERROR:
                hls.recoverMediaError();
                break;
              default:
                setVideoStatus("error");
                setErrorMessage("Failed to load HLS stream");
                hls.destroy();
                break;
            }
          }
        });
      } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
        // Native HLS (e.g., Safari)
        video.src = url;
        video.addEventListener("loadedmetadata", () => {
          setVideoStatus("ready");
        });
        video.addEventListener("error", () => {
          setVideoStatus("error");
          setErrorMessage("Failed to load HLS stream natively");
        });
      } else {
        setVideoStatus("error");
        setErrorMessage("HLS streaming is not supported in this browser");
      }
    } else {
      // Normal Direct MP4 / WebM
      video.src = url;
      videoStatus === "loading" && setVideoStatus("ready");
      video.addEventListener("loadedmetadata", () => {
        setVideoStatus("ready");
      });
      video.addEventListener("error", () => {
        setVideoStatus("error");
        setErrorMessage("Failed to decode video source");
      });
    }

    // Apply starting volume
    video.volume = isMuted ? 0 : volume;

    return () => {
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
    };
  }, [url]);

  // Synchronize playback with incoming backend/host sync props
  useEffect(() => {
    const video = videoRef.current;
    if (!video || videoStatus !== "ready" || isHost || !syncEnabled) return;

    // Check play state sync
    if (isPlaying && video.paused) {
      runWithoutSyncCycle(() => {
        video.play().catch(() => {});
        setLocalIsPlaying(true);
      });
    } else if (!isPlaying && !video.paused) {
      runWithoutSyncCycle(() => {
        video.pause();
        setLocalIsPlaying(false);
      });
    }

    // Drift / late-join synchronization (threshold of 2 seconds)
    const drift = Math.abs(video.currentTime - currentTime);
    if (drift > 2) {
      runWithoutSyncCycle(() => {
        video.currentTime = currentTime;
      });
    }
  }, [isPlaying, currentTime, videoStatus, isHost, syncEnabled]);

  // Handle local plays and seek events
  const handlePlayPause = () => {
    const video = videoRef.current;
    if (!video || videoStatus !== "ready") return;

    // In watch parties, guests can only control local playback if sync is disabled, or they are host.
    // However, if they seek/pause, we can either block them or trigger play/sync signals.
    // Requirement check: "play, pause, seek are synchronized"
    if (!isHost && syncEnabled) {
      // If sync is enabled, guests shouldn't interfere with general room sync,
      // but if they click play, we can play locally or send host sync signal.
      // Let's allow clicking play but sync with server.
    }

    if (video.paused) {
      video.play().catch(() => {});
      setLocalIsPlaying(true);
      if (onPlay && (!syncEnabled || isHost)) {
        onPlay(video.currentTime);
      }
    } else {
      video.pause();
      setLocalIsPlaying(false);
      if (onPause && (!syncEnabled || isHost)) {
        onPause(video.currentTime);
      }
    }
  };

  const handleSeekChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const video = videoRef.current;
    if (!video || videoStatus !== "ready") return;
    if (!isHost && syncEnabled) return; // Only host/unsynced can seek

    const seekTime = parseFloat(e.target.value);
    video.currentTime = seekTime;
    setProgress(seekTime);
    if (onSeek) {
      onSeek(seekTime);
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const video = videoRef.current;
    if (!video) return;
    const v = parseFloat(e.target.value);
    setVolume(v);
    setIsMuted(v === 0);
    video.volume = v;
    video.muted = v === 0;
  };

  const toggleMute = () => {
    const video = videoRef.current;
    if (!video) return;
    const newMute = !isMuted;
    setIsMuted(newMute);
    video.muted = newMute;
    video.volume = newMute ? 0 : volume;
  };

  const handleTimeUpdate = () => {
    const video = videoRef.current;
    if (!video) return;

    setProgress(video.currentTime);
    if (video.duration) {
      setDuration(video.duration);
    }

    // Call updates from host to push to downstream clients
    if (onTimeUpdate && !isSyncingFromProp.current) {
      onTimeUpdate(video.currentTime);
    }
  };

  const handleQualityChange = (index: number) => {
    setCurrentQuality(index);
    if (hlsRef.current) {
      hlsRef.current.currentLevel = index;
    }
  };

  const toggleFullscreen = () => {
    const video = videoRef.current;
    if (!video) return;
    if (video.requestFullscreen) {
      video.requestFullscreen();
    }
  };

  const formatTime = (time: number) => {
    if (isNaN(time) || !isFinite(time)) return "Live";
    const mins = Math.floor(time / 60);
    const secs = Math.floor(time % 60);
    return `${mins}:${secs < 10 ? "0" : ""}${secs}`;
  };

  return (
    <div id="iptv_player_root" className="relative group w-full aspect-video bg-neutral-950 rounded-xl overflow-hidden border border-white/5 shadow-2xl">
      {/* Stream Status Indicator */}
      <div className="absolute top-4 left-4 z-20 flex gap-2">
        <span className="flex items-center gap-1.5 px-3 py-1 bg-red-650/90 backdrop-blur-md rounded-full text-white text-xs font-semibold uppercase tracking-wider animate-pulse shadow-md">
          <Radio className="w-3.5 h-3.5 animate-spin" />
          Live Platform
        </span>
        {syncEnabled && (
          <span className="px-3 py-1 bg-orange-500/90 backdrop-blur-md rounded-full text-black text-xs font-black uppercase tracking-wider shadow-md">
            Sync: {isHost ? "Host Controls" : "Synced View"}
          </span>
        )}
      </div>

      {videoStatus === "loading" && (
        <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-neutral-950/80 gap-3">
          <div className="w-12 h-12 border-4 border-orange-500 border-t-transparent rounded-full animate-spin"></div>
          <p className="text-neutral-400 font-medium text-sm">Opening IPTV stream...</p>
        </div>
      )}

      {videoStatus === "error" && (
        <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-neutral-950/90 text-center p-6 gap-3">
          <AlertTriangle className="w-16 h-16 text-yellow-500" />
          <h4 className="text-neutral-200 font-bold text-lg">Playback Unreachable</h4>
          <p className="text-neutral-500 text-sm max-w-sm">{errorMessage || "Stream returned offline status. Try another category."}</p>
          <button 
            onClick={() => {
              if (videoRef.current) {
                videoRef.current.load();
              }
            }}
            className="mt-2 flex items-center gap-2 px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-sm font-semibold rounded-lg border border-neutral-700 transition"
          >
            <RotateCcw className="w-4 h-4" />
            Reload Stream
          </button>
        </div>
      )}

      {/* Main Video Element */}
      <video
        ref={videoRef}
        className="w-full h-full object-contain"
        onPlay={() => setLocalIsPlaying(true)}
        onPause={() => setLocalIsPlaying(false)}
        onTimeUpdate={handleTimeUpdate}
        autoPlay={isPlaying}
        controls={false}
        playsInline
      />

      {/* Sleek Custom Control Overlay */}
      <div className="absolute bottom-0 left-0 right-0 h-28 bg-gradient-to-t from-neutral-950/95 via-neutral-950/60 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-300 flex flex-col justify-end p-4 gap-3 z-10">
        
        {/* Progress bar (disabled for sync unless host, or native Live stream) */}
        <div className="flex items-center gap-3 w-full">
          <span className="text-xs text-neutral-400 font-mono select-none">
            {formatTime(progress)}
          </span>
          <input
            type="range"
            min={0}
            max={duration || 100}
            step={0.1}
            value={progress}
            onChange={handleSeekChange}
            disabled={!isHost && syncEnabled}
            className="flex-1 h-1.5 rounded-lg appearance-none bg-neutral-700/60 accent-orange-500 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
          />
          <span className="text-xs text-neutral-400 font-mono select-none">
            {formatTime(duration)}
          </span>
        </div>

        {/* Action Controls */}
        <div className="flex items-center justify-between w-full">
          <div className="flex items-center gap-4">
            <button
              onClick={handlePlayPause}
              disabled={!isHost && syncEnabled}
              className="p-2 text-white hover:text-orange-400 rounded-full hover:bg-neutral-800/80 transition disabled:opacity-50 disabled:hover:text-white"
            >
              {localIsPlaying ? <Pause className="w-5 h-5 fill-white" /> : <Play className="w-5 h-5 fill-white" />}
            </button>

            {/* Volume Control */}
            <div className="flex items-center gap-2">
              <button
                onClick={toggleMute}
                 className="p-1.5 text-neutral-400 hover:text-white rounded-lg transition"
              >
                {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
              </button>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={isMuted ? 0 : volume}
                onChange={handleVolumeChange}
                className="w-16 h-1 rounded-full appearance-none bg-neutral-700/80 accent-orange-500 cursor-pointer"
              />
            </div>
          </div>

          <div className="flex items-center gap-3">
            {qualities.length > 0 && (
              <div className="flex items-center gap-1.5 text-xs text-neutral-400">
                <span className="text-[10px] font-bold uppercase text-neutral-500 font-mono">Qual:</span>
                <select
                  value={currentQuality}
                  onChange={(e) => handleQualityChange(Number(e.target.value))}
                  className="bg-neutral-900/90 border border-white/10 rounded px-1.5 py-0.5 text-[11px] font-bold text-neutral-200 focus:outline-none focus:border-orange-500 cursor-pointer"
                >
                  {qualities.map((q) => (
                    <option key={q.index} value={q.index} className="bg-neutral-950 text-white">
                      {q.label}
                    </option>
                  ))}
                </select>
              </div>
            )}
            <button
              onClick={toggleFullscreen}
              className="p-2 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800/80 transition"
              title="Fullscreen"
            >
              <Maximize className="w-5 h-5" />
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
